/*
 * ADCGeneric.c
 *
 *  Created on: 12 mar 2026
 *      Author: L
 */


#include"ADCGeneric.h"


/*
 * ATTENZIONE, tutti i valori escono espressi in mV
 * questa funzione fa anche le medie e tiene conto dei tempi di delay prima della prima acquisizione!
 */
void readVoltage(uint16_t *readVoltage, uint16_t *refVoltage, uint32_t channel, configurazioneAnalogSensor_t *config)
{
	//    // Se il sensore è disabilitato
	//    if (!config->EnableSensore)
	//    {
	//        *readVoltage = 0;
	//        *refVoltage  = 0;
	//        return;
	//    }

	uint32_t measuredVRefLevel = 0;
	uint32_t rawVRefLevel = ADC_ReadChannel(ADC_CHANNEL_VREFINT);

	if ((uint32_t)*VREFINT_CAL_ADDR != 0xFFFFU)
	{
		measuredVRefLevel = __LL_ADC_CALC_VREFANALOG_VOLTAGE(rawVRefLevel, ADC_RESOLUTION_12B);
	}
	else
	{
		measuredVRefLevel = 3300;
	}

	*refVoltage = measuredVRefLevel;

	if (config->preSample > 0)
	{
		HAL_Delay(config->preSample);
	}

	uint32_t sum = 0;

	for (uint8_t i = 0; i < config->numSamples; i++)
	{
		uint16_t raw = ADC_ReadChannel(channel);
		sum += raw;
	}
	if (config->numSamples == 0)
		config->numSamples = 1;
	uint16_t avgRaw = (uint16_t)(sum / config->numSamples);

	*readVoltage = __LL_ADC_CALC_DATA_TO_VOLTAGE( measuredVRefLevel, avgRaw, ADC_RESOLUTION_12B);
}

void readAllChannels(configurazioneAnalogSensor_t *config, uint16_t *Voltage, uint16_t *refVoltage)
{
	// attivo l'alimentazione per i sensori analogici
	powerStages(POWER_STAGE_ANALOG_POWERIN, POWER_ON);
	// diamo il tempo che si attivi l'uscita
	HAL_Delay(1);

	for (uint8_t i = 0; i < ANALOG_INPUT; i++)
	{
		if (config[i].EnableSensore)
		{
			// selezione il relativo ingresso del MUX
			analog_mux_select_input((Analog_Input_t)i);
			readVoltage(&Voltage[i], &refVoltage[i], AnalogINCH, &config[i]);
		}
		else
		{
			Voltage[i] = 0;
			refVoltage[i]  = 0;
		}
	}
	// stacco l'alimentazione
	powerStages(POWER_STAGE_ANALOG_POWERIN, POWER_OFF);
	// se tengp tutto alto non dovrei avere consumo di corrente, in quanto le R di PU non vengono cortocircuitate a GND
	analog_mux_select_input(Analog3);
	// ma per non sbagliare disattivo direttamente le uscite
	analog_mux_LowPower();

}
