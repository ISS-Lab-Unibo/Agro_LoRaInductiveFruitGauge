/*
 * ADCGeneric.h
 *
 *  Created on: 12 mar 2026
 *      Author: L
 */

#ifndef ADCGENERIC_ADCGENERIC_H_
#define ADCGENERIC_ADCGENERIC_H_

#include "adc_if.h"
#include "LORaNodeConfig.h"
#include "tmux1204.h"
#include "GPIOSet.h"

typedef enum
{
    AnalogINCH = ADC_CHANNEL_5
} ADC_Channel_t;


void readVoltage(uint16_t *readVoltage, uint16_t *refVoltage, uint32_t channel, configurazioneAnalogSensor_t *config);

void readAllChannels(configurazioneAnalogSensor_t *config, uint16_t *Voltage, uint16_t *refVoltage);


#endif /* ADCGENERIC_ADCGENERIC_H_ */
