/*
 * timInputCapture.h.c
 *
 *  Created on: 13 mar 2026
 *      Author: L
 */

#include "timInputCapture.h"
#include "tim.h"
#include "sys_app.h"
#include <math.h>
#include "stdio.h"

// completato serve a dire che il ciclo di letture è stato terminato
uint8_t completato = 0;
uint8_t completatoTemperatura = 0;
uint16_t idealTickTime = 0;
uint16_t numLetture = 0;
uint16_t counts[MAXCOUNT];
uint16_t ticks[MAXCOUNT - 1];
float realUsPerTick = 0;

extern TIM_HandleTypeDef htim16;
extern TIM_HandleTypeDef htim17;

extern float durataSingoloCount;

/* extern */

uint16_t conversioneInUsSingle(uint16_t differenza);
uint16_t conversioneInRealTickSingle(uint16_t differenza);

void stopTIM16()
{
	HAL_StatusTypeDef stato = HAL_TIM_IC_Stop_DMA(&htim16, TIM_CHANNEL_1);
	if (stato != HAL_OK)
	{
		Error_Handler();
	}
}

void stopTIM17()
{
	HAL_StatusTypeDef stato = HAL_TIM_IC_Stop_DMA(&htim17, TIM_CHANNEL_1);
	if (stato != HAL_OK)
	{
		Error_Handler();
	}
}

void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
/*
 * non usa gli array
 */
{
	if (htim->Instance == TIM16)

	{
		/* timer SENT */
		if(htim->Channel == HAL_TIM_ACTIVE_CHANNEL_1)
		{
			stopTIM16();
			completato++;
			//		SEGGER_RTT_printf(0, "Letture completate\n\r");
			//		TIM16_DeInit();

		}

		/*
		 * qui si fa il recovery del tempo per ciascun tick
		 */
		// Calcola ±10% del valore di riferimento del tick ( da specifiche clock) analizzando i campioni che dovrebbero essere da 51 tick
		float delta = (float)idealTickTime / 100 * 10;
		float min = (float)idealTickTime - delta;
		float max = (float)idealTickTime + delta;
		uint32_t accumulatore = 0;
		uint16_t contatore = 0;

		uint16_t differenza;
		uint16_t us;
		/*
		 * Analizzo ciascun intervallo di tempo
		 *
		 * ora si trovano le differenze temporali, cerco gli intervalli da 51 impulsi e trovo il tick corretto
		 */
		for (uint8_t i = 0; i<numLetture-1; i++)
		{
			if (counts[i+1] > counts[i])

				differenza = counts[i+1] - counts[i];
			else
				differenza = 0xFFFF + counts[i+1] - counts[i];

			/*
			 * ora calcolo la durata media, in count, della parte da 51 tick dell'impulso di calibrazione, così si può ricavare l'effettivo periodo di ogni tick generato dal chip
			 *  prima cerco i tick vicini a 51,, con una incertezza del 10% sui 3 us per tick
			 */
			us = conversioneInUsSingle(differenza);
			if ((us >= (min*51)) && (us <= (max*51)))
			{
				accumulatore = accumulatore + differenza;
				contatore++;
			}
		}

		realUsPerTick = (float)accumulatore/(float)contatore/(float)51*durataSingoloCount;
//	    char str[100];
//	    snprintf(str, sizeof(str), "valore in us di ogni tick: %.2f\n\r", realUsPerTick);
//		APP_LOG( TS_OFF, VLEVEL_M, str);

		for (uint8_t i = 0; i<numLetture-1; i++)
		{
			if (counts[i+1] > counts[i])

				differenza = counts[i+1] - counts[i];
			else
				differenza = 0xFFFF + counts[i+1] - counts[i];
			ticks[i] = conversioneInRealTickSingle(differenza);
		}
	}

	if (htim->Instance == TIM17)
	{
		/* timer temperatura */
		stopTIM17();
		completatoTemperatura++;
	}

}


uint16_t conversioneInUsSingle(uint16_t differenza)
{
	/*
	 * converte un valore alla volta
	 */
	return (uint16_t)round((float)differenza*durataSingoloCount);
}

uint16_t conversioneInRealTickSingle(uint16_t differenza)
{
	/*
	 * converto in lunghezza di tick, con ipotesi che tick valga 3 us
	 */
	return (uint16_t)round((float)differenza*durataSingoloCount/realUsPerTick);
}


void timeMeterAvvio(uint16_t letture, uint16_t tickTime)
{
	inizializzaArrayAZero(counts, MAXCOUNT);
	idealTickTime = tickTime;
	numLetture = letture;
	//	inizializzaArrayAZero(differenze, maxCount - 1);
	//	inizializzaArrayAZero(us, maxCount - 1);
	//	inizializzaArrayAZero(ticks, maxCount - 1);
	//HAL_Delay(10);
	HAL_StatusTypeDef error = HAL_TIM_IC_Start_DMA(&htim16, TIM_CHANNEL_1, (uint32_t*)counts, numLetture);
	if( error!= HAL_OK)
	{
		/* Starting Error */
		Error_Handler();
	}
}

void inizializzaArrayAZero(uint16_t* array, size_t lunghezza) {
	for (size_t i = 0; i < lunghezza; i++) {
		array[i] = 0;
	}
}
