/*
 * stat.c
 *
 *  Created on: 17 mar 2026
 *      Author: L
 */

#include <stat.h>


uint16_t dataStat[MAXLENGTHSTAT];
uint8_t statLength = 0;




// Funzione per calcolare media e (opzionalmente) deviazione standard

// sevuoi solo la media scrivi calcola_statistiche(array, n, &media, NULL);

void calcola_statistiche(const uint16_t *array, uint16_t lunghezza, float *media, float *dev_std) {
    if (lunghezza == 0 || array == NULL || media == NULL) {
        if (media) *media = 0.0;
        if (dev_std) *dev_std = 0.0;
        return;
    }

    // Calcolo della media
    float somma = 0.0f;
    for (size_t i = 0; i < lunghezza; i++) {

        somma += array[i];
    }
    *media = somma / (float)lunghezza;

    // Se non serve la deviazione standard, esci
    if (dev_std == NULL) {
        return;
    }

    // Calcolo della deviazione standard
    float somma_quadrati = 0.0f;
    for (size_t i = 0; i < lunghezza; i++) {
        float diff = array[i] - *media;
        somma_quadrati += diff * diff;
    }
    *dev_std = sqrtf(somma_quadrati / (float)lunghezza);
}
