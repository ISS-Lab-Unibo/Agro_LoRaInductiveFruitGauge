/*
 * timInputCapture.h
 *
 *  Created on: 13 mar 2026
 *      Author: L
 */

#ifndef TIM2INPUTCAPTURE_TIMINPUTCAPTURE_H_
#define TIM2INPUTCAPTURE_TIMINPUTCAPTURE_H_

#include <main.h>

#define MAXCOUNT 200

void stopTIM16();
void stopTIM17();
void inizializzaArrayAZero(uint16_t* array, size_t lunghezza);
void timeMeterAvvio(uint16_t letture, uint16_t tickTime);
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim);
void inizializzaArrayAZero(uint16_t* array, size_t lunghezza);

#endif /* TIM2INPUTCAPTURE_TIMINPUTCAPTURE_H_ */
