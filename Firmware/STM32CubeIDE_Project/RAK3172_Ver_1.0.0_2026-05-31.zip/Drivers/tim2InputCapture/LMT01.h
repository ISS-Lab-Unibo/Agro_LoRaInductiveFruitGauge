/*
 * LMT01.h
 *
 *  Created on: 23 mar 2026
 *      Author: L
 */

#ifndef TEMPERATURESENSING_LMT01_H_
#define TEMPERATURESENSING_LMT01_H_


#include <stdint.h>

#define LUT_SIZE (sizeof(lut)/sizeof(lut[0]))

#define SIZE_ARRAY_COUNT_TEMP 	4100 * 2	// il massimo numero di impulsi sarebbe 4096, ma se si parte mentre il sensore sta erogando "a metà" un altro valore non va bene
#define MAX_TIMEOUT_TEMP		200			// massimo numero di msec che possimo aspettare, per essere sicuri che si sia letto almeno un gruppo di impulsi, tra due "pause"

#define MSEC_FRONTI_SALITA_TYP 11.36
#define MSEC_INCERTEZZA 0.84	// guarda Excel
#define MSEC_MIN_FRONTI MSEC_FRONTI_SALITA_TYP-MSEC_INCERTEZZA
#define MSEC_MAX_FRONTI MSEC_FRONTI_SALITA_TYP+MSEC_INCERTEZZA
#define MAX_PAUSE 5

typedef struct {
    uint16_t pulses;
    int16_t temp_c; // temperatura in celsius
} LUTEntry;

static const LUTEntry lut[] = {
    {26,  -50}, {181, -40}, {338, -30}, {494, -20}, {651, -10},
    {808,   0}, {966,  10}, {1125, 20}, {1284, 30}, {1443, 40},
    {1602, 50}, {1762, 60}, {1923, 70}, {2084, 80}, {2245, 90},
    {2407,100}, {2569,110}, {2731,120}, {2893,130}, {3057,140},
    {3218,150}
};
/*
 * lut biecamente copiata da https://www.ti.com/lit/ds/symlink/lmt01.pdf?ts=1774270418629, valori tipici
*/

float lmt01_pulses_to_temp(uint16_t pulses);
float leggiTemperatura();



#endif /* TEMPERATURESENSING_LMT01_H_ */
