/*
 * sent.c
 *
 *  Created on: 17 mar 2026
 *      Author: L
 */

#include "sent.h"
#include "sys_app.h"
#include "tim.h"
#include "stat.h"
#include "stdio.h"
#include "GPIOSet.h"
#include "i2c.h"
#include "tca9534.h"
#include "sel74hc151.h"
#include "LMT01.h"

#define SENT_TIMEOUT 2000

//#define STAMPA

#ifdef STAMPA
#define STAMPALETTI
//#define STAMPAMEDIE
//#define STAMPAERRORI
#define VERBOSO
#endif

#define LOG(enable, text, ...)      			\
		do {                                        \
			if (enable) {                           \
				APP_LOG(                            \
						TS_OFF,                         \
						VLEVEL_M,                       \
						text,                           \
						__VA_ARGS__                     \
				);                                  \
			}                                       \
		} while(0)

#define SENT_TICK 24

uint8_t nibbleNum = 0;


extern uint16_t counts[MAXCOUNT];
extern uint16_t ticks[];
extern uint16_t numLetture;
extern uint8_t statLength;
extern uint8_t completato;

uint8_t crcData[6];
uint8_t crcDataCounter = 0;
uint32_t dataSent = 0;
//uint16_t decodedData[10];
uint8_t decodedNumber = 0;
sentData_t dati[10];
uint8_t SentDecodedDataNumerosity = 0;
uint8_t medie_da_effettuare;
TCA9534_Pinza_t numPinze;
uint8_t medieOkFlag = 0;

char scritte[100];

extern uint16_t dataStat[];
extern expander_t expanderI2C;
extern I2C_HandleTypeDef hi2c2;

void sentError();

void lettureSent(configurazionePinze_t *config, float *media, float *DEVstd, float *temperatura, bool verboso)
{
	// inizializzo il contatore
	MX_TIM16_Init();
	// anche quello per la temperatura
	MX_TIM17_Init();

	powerStages(POWER_STAGE_PINZE_ON, POWER_ON);
	powerStages(POWER_STAGE_BOOST_ON_PINZE, POWER_ON);


	// attivo l'expander I2C
	MX_I2C2_Init();
	expander_init(&expanderI2C, &hi2c2, TCA9534_ADDR_A2A1A0_000, 1000);
	expander_write_pinze(&expanderI2C, TCA9534_PINZA0|TCA9534_PINZA1|TCA9534_PINZA2|TCA9534_PINZA3|TCA9534_PINZA4|TCA9534_PINZA5|TCA9534_PINZA6|TCA9534_PINZA7, TCA9534_SPENTO);


	uint32_t startTick = 0;
	bool timeElapsed = false;
	// scorro tutte le pinze
	for (uint8_t i = 0; i<MAX_NUM_PINZE; i++)
		//	for (uint8_t i = 0; i<1; i++)
	{
		if (config[i].pinzaEnable == PINZA_ATTIVA)
		{
			completato = 0;
			medie_da_effettuare = config[i].AverageNum;
			// seleziono l'opportuno ingresso del mux
			hc151_select_input(i);
			// accendo la pinza
			expander_write_pinze(&expanderI2C, (TCA9534_Pinza_t)(1<<i), TCA9534_ACCESO);
			do
			{
				startSentReading(180);
				startTick = HAL_GetTick();
				while ((completato == 0) && (timeElapsed == false))
				{
					HAL_Delay(1);
					if ((HAL_GetTick() - startTick)>SENT_TIMEOUT)
						timeElapsed = true;
				}
				if (completato != 0)
					//				if (timeElapsed == false)
				{
					//					APP_LOG( TS_OFF, VLEVEL_M, "######### ---LETTURA SENT PINZA %d COMPLETATA------#########\n\r", i);
					LOG(verboso, "######### ---LETTURA SENT PINZA %d COMPLETATA------#########\n\r", i);

					// resetto il flag che mi diche che le letture di N nibble sono state fatte
					completato = 0;
					// spengo la pinza

					decodeData(&media[i], &DEVstd[i]);
				}
				if (timeElapsed == true)
					//				else // vuol dire che
				{
					//					APP_LOG( TS_OFF, VLEVEL_M, "######### --- Uscita sent pinza %d da Timeout------#########\n\r", i);
					LOG(verboso, "######### --- Uscita sent pinza %d da Timeout------#########\n\r", i);
					stopTIM16();
					media[i] = 0;
					DEVstd[i] = 0;
				}
			}
			while ((medieOkFlag == 0) && (timeElapsed == false));

			// già che siamo attivileggiamo la temperatura
			temperatura[i] = leggiTemperatura();
			if (verboso)
			{
				char scritte[100];
				sprintf(scritte, "temperatura = %4.2f,\n\r", temperatura[i]);
				APP_LOG( TS_OFF, VLEVEL_M, "%s", scritte);
			}

			expander_write_pinze(&expanderI2C, (TCA9534_Pinza_t)(1<<i), TCA9534_SPENTO);
			medieOkFlag = 0;
			timeElapsed = false;
			LOG(verboso, "######### --- Fine While pinza %d ------#########\n\r", i);
		}
		else
		{
			media[i] = 0;
			DEVstd[i] = 0;
			temperatura[i] = 0;
			LOG(verboso, "######### --- PINZA %d non attiva ------#########\n\r", i);
		}
	}
	//	expander_write_pinze(&expanderI2C, TCA9534_PINZA0|TCA9534_PINZA1|TCA9534_PINZA2|TCA9534_PINZA3|TCA9534_PINZA4|TCA9534_PINZA5|TCA9534_PINZA6|TCA9534_PINZA7, TCA9534_SPENTO);
	powerStages(POWER_STAGE_BOOST_ON_PINZE, POWER_OFF);
	powerStages(POWER_STAGE_PINZE_ON, POWER_OFF);


	hc151_mux_LowPower();

	// deinizializzo il contatore
	TIM16_DeInit();
	// anche quello per la temperatura
	TIM17_DeInit();

	HAL_I2C_DeInit(&hi2c2);
}

void startSentReading(uint8_t num_letture)
{
	//	MX_TIM16_Init();
	inizializzaArrayAZero(counts, MAXCOUNT);
	//	SEGGER_RTT_printf(0, "Letture avviate\n\r");
	//	HAL_Delay(2);
	timeMeterAvvio(num_letture, SENT_TICK);
}


uint16_t decodeData(float *media, float *devSTD)
{
	uint16_t indexStart[10];
	nibbleNum = 6;
	uint8_t validStart = 0;
	uint16_t lastIndex = 0;
	uint8_t error = 0;

	lastIndex = (numLetture - 1);
	/*
	 * controllo quanti start validi ho
	 * e vedo se il numero di intervalli temporali mi basta per rilevare gli nibbleNum NIBBLE ed il CRC
	 * salvo quindi gli indici dei nibble validi da leggere
	 */
	inizializzaArrayAZero(indexStart, 10);
	for (uint8_t i = 0; i<numLetture-3; i++)
	{
		if ((ticks[i] == 5) && (ticks[i+1] == 51))
		{
			if ((lastIndex - (i+2)) >= (2*nibbleNum + 2 + 2))		// 2 di status + nibbleNum che vale 6 (2*12 bit) + 2 di crc
			{
				indexStart[validStart] = i+2;		// puntiamo direttamente al primo nibble
				validStart++;
			}
		}
	}
	/*
	 * ora ho la lista degli indici di start, posso iniziare a leggere i vari nibble - ricorda che abbiamo tanti nibble validi quanti sono i validStart
	 */
	uint16_t actualIndex = 0;		// indice del nibble con cui stiamo lavorando
	SentDecodedDataNumerosity = 0;
	for (uint8_t i = 0; i<validStart; i++)
	{
		actualIndex = indexStart[i];
		//		SentDecodedDataNumerosity = 0;
		uint8_t nibbleCount = 0;
		dati[SentDecodedDataNumerosity].data[0] = 0;
		dati[SentDecodedDataNumerosity].data[1] = 0;

		/*
		 * analizzo nibble per nibble, cioè gruppi di 12 bit, cioè analizzo tutti i nibble ricordando che ho da considerare status e CRC
		 * e quindi scrivo tutti i dati dentro la struttura dati
		 */

		while (nibbleCount < nibbleNum + 2)		// il +2 tiene conto di status e crc
		{

			if ((ticks[actualIndex] == 5) && (ticks[actualIndex+1] >= 7) && (ticks[actualIndex+1] <= 22) ) 	// ho un nibble "valido"?
			{
				if (nibbleCount == 0)	// se è il primo dopo lo start allora è lo status
				{
					dati[SentDecodedDataNumerosity].status = 0;
					dati[SentDecodedDataNumerosity].status = (uint8_t)(ticks[actualIndex+1] - 7);
				}
				else
				{
					if (nibbleCount == (nibbleNum + 2 - 1)) // se è l'ultimo allora è il CRC
					{
						dati[SentDecodedDataNumerosity].CRC_val = 0;
						dati[SentDecodedDataNumerosity].CRC_val = (uint8_t)(ticks[actualIndex+1] - 7);
					}
					else
					{
						/*
						 * Altrimenti sono gli altri "dati di mezzo"
						 * shift di 4 bit, poi ci sommo gli altri 4 bit che voglio leggere
						 */
						if (nibbleCount < 4)
						{
							// ogni volta shifto i valori di 4 bit e in append ci metto gli altri 4 bit
							dati[SentDecodedDataNumerosity].data[0] = (dati[SentDecodedDataNumerosity].data[0]<<4);
							dati[SentDecodedDataNumerosity].data[0] = dati[SentDecodedDataNumerosity].data[0] + (uint8_t)(ticks[actualIndex+1] - 7);
							//							SEGGER_RTT_printf(0, "%x", dati[SentDecodedDataNumerosity].data[0]);
							// riporto il valore per il calcolo del CRC
							crcData[crcDataCounter] = (uint8_t)(ticks[actualIndex+1] - 7);
							crcDataCounter++;
						}
						else
						{
							dati[SentDecodedDataNumerosity].data[1] = (dati[SentDecodedDataNumerosity].data[1]<<4);
							dati[SentDecodedDataNumerosity].data[1] = dati[SentDecodedDataNumerosity].data[1] + (uint8_t)(ticks[actualIndex+1] - 7);
							// riporto il valore per il calcolo del CRC
							crcData[crcDataCounter] = (uint8_t)(ticks[actualIndex+1] - 7);
							crcDataCounter++;
						}
					}
				}
				//				crcDataCounter++;
			}
			else
			{
				/*
				 * c'è qualche problema coi dati, non rientrano nei range corretti
				 */
				error = 1;
				crcDataCounter = 0;
			}
			/*
			 * segno di aver contato un nibble in più e mi sposto
			 */
			nibbleCount++;
			actualIndex = actualIndex + 2;
		}//while

		/*
		 * controllo il CRC
		 */
		/* qui calcolo il CRC per ogni singolo nibble */
		uint8_t crcComputed = crcCalcSingleNibble(crcData);
		crcDataCounter = 0;
		/*
		 * CONTROLLO CRC
		 */
		if (crcComputed != dati[SentDecodedDataNumerosity].CRC_val)
		{
			error++;
#ifdef STAMPAERRORI
			APP_LOG( TS_OFF, VLEVEL_M, "Errore da CRC!_dato: 0x%x -> ", dati[SentDecodedDataNumerosity].data[0]);
			APP_LOG( TS_OFF, VLEVEL_M, "%d_", dati[SentDecodedDataNumerosity].data[0]);
			APP_LOG( TS_OFF, VLEVEL_M, "0x%x_->_", dati[SentDecodedDataNumerosity].data[1]);
			APP_LOG( TS_OFF, VLEVEL_M, "%d_", dati[SentDecodedDataNumerosity].data[1]);
			APP_LOG( TS_OFF, VLEVEL_M, "status_=_%x_", dati[SentDecodedDataNumerosity].status);
			APP_LOG( TS_OFF, VLEVEL_M, "CRC_=_%x_", dati[SentDecodedDataNumerosity].CRC_val);
			//		SEGGER_RTT_printf(0, "Calcolo del CRC: ");
			APP_LOG( TS_OFF, VLEVEL_M, "Calcolo_CRC:_%x\n\r", crcComputed);
#endif

		}
		if (error == 0)
		{
			/*
			 * se non c'è errore incremento il contatore dei dati correttamente interpretati
			 * che potrò usare per fare delle staistiche
			 */
			//			SEGGER_RTT_printf(0, "\n");
			//			dataStat[statLength] = dati[SentDecodedDataNumerosity].data[0];		// dati per analisi statistica
			//			statLength++;
#ifdef  STAMPALETTI
				APP_LOG( TS_OFF, VLEVEL_M, " NO ERRORE -> dato: %d ", dati[SentDecodedDataNumerosity].data[0]);
				APP_LOG( TS_OFF, VLEVEL_M, " statLength -> %d", statLength);
				APP_LOG( TS_OFF, VLEVEL_M, " su %d ", medie_da_effettuare);
				//			APP_LOG( TS_OFF, VLEVEL_M, "%x\t", dati[SentDecodedDataNumerosity].data[1]);
				//			APP_LOG( TS_OFF, VLEVEL_M, "status = %x\t", dati[SentDecodedDataNumerosity].status);
				//			APP_LOG( TS_OFF, VLEVEL_M, "CRC = %x\t", dati[SentDecodedDataNumerosity].CRC_val);
				//			APP_LOG( TS_OFF, VLEVEL_M, "Calcolo del CRC: ");
				//			APP_LOG( TS_OFF, VLEVEL_M, "%x\n\r", crcComputed);
#endif
			if ((statLength < medie_da_effettuare) && (medieOkFlag == 0))
			{
				dataStat[statLength] = dati[SentDecodedDataNumerosity].data[0];		// dati per analisi statistica
				statLength++;
#ifdef  STAMPALETTI
				APP_LOG( TS_OFF, VLEVEL_M, "dato salvato: %d\n\r", dataStat[statLength-1]);
#endif
			}
			else
			{
				// se non abbiamo ancora calcolato le medie, calcoliamole, ma solo una volta!
				if (medieOkFlag == 0)
				{
					calcola_statistiche(dataStat, medie_da_effettuare, media, devSTD);
					statLength = 0;
					medieOkFlag = 1;
#ifdef STAMPAMEDIE
					sprintf(scritte, "###### ---------- ######\n\rstatistica degli ultimi %d valori validi: media = %4.2f, DevSTD = %4.2f\n\r", statLength, *media, *devSTD);
					APP_LOG( TS_OFF, VLEVEL_M, "%s\n\r", scritte);
#endif
				}
			}
#ifdef STAMPALETTI
			APP_LOG( TS_OFF, VLEVEL_M, "\n\r");
#endif
			SentDecodedDataNumerosity++;
		}
		else
		{
			sentError();
		}
		error = 0;
	}// for degli start
	return SentDecodedDataNumerosity;
}


uint8_t crcCalc (uint32_t crcData)
{
	uint8_t calculatedCRC, i;
	const uint8_t CrcLookup[16] = {0, 13, 7, 10, 14, 3, 9, 4, 1, 12, 6, 11, 15, 2, 8, 5};
	calculatedCRC = 5; // initialize checksum with seed "0101"

	for (i = 0; i < 6; i++)
	{
		uint8_t crcDatum = (crcData >> 24) & 0x0F;

		calculatedCRC = CrcLookup[calculatedCRC];
		calculatedCRC = calculatedCRC ^ crcDatum;

		//	    calculatedCRC = pow(calculatedCRC, crcDatum);

		crcData <<= 4;
	}
	// One more round with 0 as input
	calculatedCRC = CrcLookup[calculatedCRC];
	return calculatedCRC;
}

uint8_t crcCalcSingleNibble(uint8_t* Data)
{
	uint8_t calculatedCRC, i;
	const uint8_t CrcLookup[16] = {0, 13, 7, 10, 14, 3, 9, 4, 1, 12, 6, 11, 15, 2, 8, 5};
	calculatedCRC = 5; // initialize checksum with seed "0101"

	for (i = 0; i < 6; i++)
	{
		calculatedCRC = CrcLookup[calculatedCRC];
		calculatedCRC = (calculatedCRC ^ Data[i]) & 0x0F;
	}
	// One more round with 0 as input
	calculatedCRC = CrcLookup[calculatedCRC];
	return calculatedCRC;
	crcDataCounter = 0;
}

void sentError()
{
	APP_LOG( TS_OFF, VLEVEL_M, "errore in lettura SENT\n\r");

}
