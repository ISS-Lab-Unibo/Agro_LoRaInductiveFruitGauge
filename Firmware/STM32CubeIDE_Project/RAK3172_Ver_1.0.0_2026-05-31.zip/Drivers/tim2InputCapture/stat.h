/*
 * stat.h
 *
 *  Created on: 17 mar 2026
 *      Author: L
 */

#ifndef TIM2INPUTCAPTURE_STAT_H_
#define TIM2INPUTCAPTURE_STAT_H_


#include <math.h>
#include <stdint.h>

#define MAXLENGTHSTAT 100

void calcola_statistiche(const uint16_t *array, uint16_t lunghezza, float *media, float *dev_std);


#endif /* TIM2INPUTCAPTURE_STAT_H_ */
