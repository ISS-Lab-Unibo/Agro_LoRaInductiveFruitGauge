/*
 * sent.h
 *
 *  Created on: 17 mar 2026
 *      Author: L
 */

#ifndef TIM2INPUTCAPTURE_SENT_H_
#define TIM2INPUTCAPTURE_SENT_H_

#include "timInputCapture.h"
#include "LoRaNodeConfig.h"


typedef struct
{
	uint16_t data[2];
	uint8_t status;
	uint8_t CRC_val;
} sentData_t;

void startSentReading(uint8_t num_letture);

uint8_t crcCalcSingleNibble(uint8_t* Data);
uint8_t crcCalc (uint32_t crcData);
uint16_t decodeData(float *media, float *devSTD);

void lettureSent(configurazionePinze_t *config, float *media, float *DEVstd, float *temperatura, bool verboso);



#endif /* TIM2INPUTCAPTURE_SENT_H_ */
