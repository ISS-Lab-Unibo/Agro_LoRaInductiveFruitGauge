/*
 * LMT01.c
 *
 *  Created on: 23 mar 2026
 *      Author: L
 */

#include "LMT01.h"
#include "tim.h"
#include "main.h"
#include "stdbool.h"
#include "sys_app.h"
#include "timInputCapture.h"


uint32_t startTick = 0;
bool timeElapsed = false;

extern float durataSingoloCountTIM17;

extern TIM_HandleTypeDef htim17;

extern uint8_t completatoTemperatura;



float lmt01_pulses_to_temp(uint16_t pulses)
{
	// fuori range
	if (pulses <= lut[0].pulses)
		return lut[0].temp_c;

	if (pulses >= lut[LUT_SIZE-1].pulses)
		return lut[LUT_SIZE-1].temp_c;

	// ricerca intervallo
	for (int i = 0; i < LUT_SIZE - 1; i++) {
		if (pulses >= lut[i].pulses && pulses <= lut[i+1].pulses) {

			float x0 = lut[i].pulses;
			float x1 = lut[i+1].pulses;
			float y0 = lut[i].temp_c;
			float y1 = lut[i+1].temp_c;

			// interp. lineare
			return y0 + (pulses - x0) * (y1 - y0) / (x1 - x0);
		}
	}

	return 0.0f;
}


float leggiTemperatura()
{
	uint16_t arrayTransizioni[SIZE_ARRAY_COUNT_TEMP];
	inizializzaArrayAZero(arrayTransizioni, SIZE_ARRAY_COUNT_TEMP);
	timeElapsed = false;


	// faccio partire il count
	HAL_StatusTypeDef errorTEMP = HAL_TIM_IC_Start_DMA(&htim17, TIM_CHANNEL_1, (uint32_t*)arrayTransizioni, SIZE_ARRAY_COUNT_TEMP);
	if(errorTEMP != HAL_OK)
	{
		/* Starting Error */
		//		APP_LOG( TS_OFF, VLEVEL_M, "--- Errore avvio TIM17 ------\n\r");
		return 25.0f;
	}

	//	APP_LOG( TS_OFF, VLEVEL_M, "--- TIM17 avviato correttamente ------\n\r");
	timeElapsed = false;
	// leggiamo finchè non termina il timeout
	startTick = HAL_GetTick();
	//	while (timeElapsed == false)
	//	{
	//		HAL_Delay(1);
	////		APP_LOG( TS_OFF, VLEVEL_M, "Delay TIM17\n\r");
	//
	//		if ((HAL_GetTick() - startTick)>MAX_TIMEOUT_TEMP)
	//		{
	//			timeElapsed = true;
	//			stopTIM17();
	////			APP_LOG( TS_OFF, VLEVEL_M, "STOP TIM17 TEMP per timeout\n\r");
	//		}
	do
	{
		HAL_Delay(1);
		//		APP_LOG( TS_OFF, VLEVEL_M, "Delay TIM17\n\r");

		if ((HAL_GetTick() - startTick)>MAX_TIMEOUT_TEMP)
		{
			timeElapsed = true;
			stopTIM17();
			//			APP_LOG( TS_OFF, VLEVEL_M, "STOP TIM17 TEMP per timeout\n\r");
		}
	}
	while ((timeElapsed == false) && (completatoTemperatura == 0));
	stopTIM17();
	// se facciamo i conti, vediamo che i periodi "off" sono di 54 ms massimo, mentre la massima lunghezza del periodo è 104 ms. Quindi, con 200 ms, siamo sicuri di prendere sicuramente due intervalli lunghi.
	// non mi serve quindi attendere che il buffer di lettura si sia riempito, possiamo operare siaa tempo che con la massima lunghezza del buffer.
	// se si ferma prima per raggiunto counter lo stoppiamo nella callback
	/*
	 * valutiamo le differenze tra i vari eintervalliletti
	 */
	//	uint16_t minPulseCount = (uint16_t)(MSEC_MIN_FRONTI/durataSingoloCountTIM17) - 1;
	uint16_t maxPulseCount = (uint16_t)(MSEC_MAX_FRONTI/durataSingoloCountTIM17) + 1;
	//		APP_LOG( TS_OFF, VLEVEL_M, "minPulseCount: %d \t maxPulseCount: %d \n\r", minPulseCount, maxPulseCount);

	uint16_t differenza[SIZE_ARRAY_COUNT_TEMP-1];
	uint16_t indexPause[MAX_PAUSE];		// qui ci mettiamo gli indici per vedere quanti impulsi ci sono tra due pause
	uint16_t countPause = 0;
	float temperatura = 0;

	// se una lettura è stata completata possiamo ritornare la temperatura, altrimenti ritorniamo zero

		// azzero il vettore delle pause
		inizializzaArrayAZero(indexPause, MAX_PAUSE);
		inizializzaArrayAZero(differenza, SIZE_ARRAY_COUNT_TEMP - 1);

		for (uint16_t i = 0; i < SIZE_ARRAY_COUNT_TEMP - 1 ; i++)
		{
			if (arrayTransizioni[i+1] >= arrayTransizioni[i])

				differenza[i] = arrayTransizioni[i+1] - arrayTransizioni[i];
			else
				differenza[i] = 0xFFFF + arrayTransizioni[i+1] - arrayTransizioni[i];
			if (differenza[i] > maxPulseCount)
			{
				indexPause[countPause] = i;
				if (countPause < MAX_PAUSE - 1)
				{
					countPause++;
				}
			}
		}
		//	APP_LOG( TS_OFF, VLEVEL_M, "Istanti 1 e 2: %d\t %d\n\r", arrayTransizioni[0], arrayTransizioni[0]);
		// controllo la distanza (in fronti) tra le prime due grandi pause, quindi quanti fronti ho contato
		if ((indexPause[1] == 0) && (indexPause[0] == 0))
			return 24.0f;
		uint16_t fronti = (indexPause[1] - indexPause[0]);
		//	APP_LOG( TS_OFF, VLEVEL_M, "Fronti: %d\n\r", fronti);
		temperatura = lmt01_pulses_to_temp(fronti);


	// ripristino i flag
	completatoTemperatura = 0;
	timeElapsed = false;
	inizializzaArrayAZero(indexPause, MAX_PAUSE);
	inizializzaArrayAZero(differenza, SIZE_ARRAY_COUNT_TEMP - 1);

	return temperatura;
}
