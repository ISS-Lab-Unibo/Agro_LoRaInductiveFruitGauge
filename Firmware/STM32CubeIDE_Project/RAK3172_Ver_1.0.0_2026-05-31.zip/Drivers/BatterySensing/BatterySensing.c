/*
 * BatterySensing.c
 *
 *  Created on: 26 gen 2026
 *      Author: L
 */


#include "BatterySensing.h"
#include "GPIOSet.h"

extern ADC_HandleTypeDef hadc;


/*
 * le tensioni escono in mV
 */
void readBatteryVoltage(uint16_t *battVoltage, uint16_t *backupBattVoltage)
{
	uint16_t tensioneBatteria = 0;
	uint16_t tensioneBatteriaBackup = 0;
	// misuro la Vref interna
	uint32_t measuredVRefLevel = 0;
	uint32_t rawVRefLevel = 0;

	rawVRefLevel = ADC_ReadChannel(ADC_CHANNEL_VREFINT);
	if ((uint32_t)*VREFINT_CAL_ADDR != (uint32_t)0xFFFFU)
	{
		/* Device with Reference voltage calibrated in production:
	         use device optimized parameters */
		measuredVRefLevel = __LL_ADC_CALC_VREFANALOG_VOLTAGE(rawVRefLevel,
				ADC_RESOLUTION_12B);
	}
	else
	{
		measuredVRefLevel = 3300;
	}

//    APP_LOG( TS_OFF, VLEVEL_M, "Raw adc Vref = %d \n\rVref interna ADC %d\n\r\n\r", rawVRefLevel, measuredVRefLevel);

	// attivo lo switch al partitore resistivo ed aspetto che si carichi
	powerStages(POWER_STAGE_VSTORAGE_READ_ACT, POWER_ON);
//	HAL_GPIO_WritePin(VStorageReadActivate_GPIO_Port, VStorageReadActivate_Pin, GPIO_PIN_SET);
	HAL_Delay(SAMPLINGDELAY);
	uint16_t raw = ADC_ReadChannel(ADC_CHANNEL_0);
	tensioneBatteria = __LL_ADC_CALC_DATA_TO_VOLTAGE(measuredVRefLevel, raw, ADC_RESOLUTION_12B);

	// poi stacco il partitore resistivo
	powerStages(POWER_STAGE_VSTORAGE_READ_ACT, POWER_OFF);
//	HAL_GPIO_WritePin(VStorageReadActivate_GPIO_Port, VStorageReadActivate_Pin, GPIO_PIN_RESET);

	// ora controllo la batteria di backup
	LL_ADC_SetCommonPathInternalCh(__LL_ADC_COMMON_INSTANCE(hadc->Instance), LL_ADC_PATH_INTERNAL_VBAT); // collego a canale 14
	HAL_Delay(1);	// LL_ADC_DELAY_TEMPSENSOR_BUFFER_STAB_US è troppo piccolo
	raw = ADC_ReadChannel(ADC_CHANNEL_VBAT);
	tensioneBatteriaBackup = __LL_ADC_CALC_DATA_TO_VOLTAGE(measuredVRefLevel, raw, ADC_RESOLUTION_12B);

	// poi disabilito la connessione interna
	LL_ADC_SetCommonPathInternalCh(__LL_ADC_COMMON_INSTANCE(hadc->Instance), LL_ADC_PATH_INTERNAL_NONE);

	// calcolo l'effettiva tensione in Volt
	*battVoltage = tensioneBatteria*BATTRATIOFACTOR;
	*backupBattVoltage = tensioneBatteriaBackup*BACKUPRATIOFACTOR;
}
