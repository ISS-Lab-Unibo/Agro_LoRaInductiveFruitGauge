/*
 * BatterySensing.h
 *
 *  Created on: 26 gen 2026
 *      Author: L
 */

#ifndef DRIVERS_BSP_LISIMETERBSP_BATTERYSENSING_BATTERYSENSING_H_
#define DRIVERS_BSP_LISIMETERBSP_BATTERYSENSING_BATTERYSENSING_H_

#include "adc.h"
#include "main.h"
#include "adc_if.h"
#include "sys_app.h"

#define SAMPLINGDELAY 20	//20 msec perchè la capacità sia completamente caricata
#define BATTRATIOFACTOR 2		// rapporto di partizione del partitore resisitivo
#define BACKUPRATIOFACTOR 3		// rapporto di partizione del partitore resisitivo

void readBatteryVoltage(uint16_t *battVoltage, uint16_t *backupBattVoltage);


#endif /* DRIVERS_BSP_LISIMETERBSP_BATTERYSENSING_BATTERYSENSING_H_ */
