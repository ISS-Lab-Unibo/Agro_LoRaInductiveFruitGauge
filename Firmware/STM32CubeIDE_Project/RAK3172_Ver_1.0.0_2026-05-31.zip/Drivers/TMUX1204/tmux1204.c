/*
 * tmux1204.c
 *
 *  Created on: 12 mar 2026
 *      Author: L
 */


#include "tmux1204.h"
#include "gpio.h"
#include "GPIOSet.h"


void analog_mux_select_input(Analog_Input_t input)
{
    // Bit 0 = SEL0, Bit 1 = SEL1
    HAL_GPIO_WritePin(ANALOG_SEL0_PORT, ANALOG_SEL0_PIN, (input & 0x01) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(ANALOG_SEL1_PORT, ANALOG_SEL1_PIN, (input & 0x02) ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

// disattiva le GPIO del microcontrollore in modo che le resistenze di PU selezionino il canale 3
void analog_mux_LowPower()
{
	// facciao così in modo da non avere una piccola caduta di tensione sulle R di PU
	analog_mux_select_input(Analog3);
//	GPIO_Analog_LP(AnSel0_GPIO_Port, AnSel1_Pin|AnSel0_Pin);
}

void analog_mux_ExitLowPower()
{
	  __HAL_RCC_GPIOA_CLK_ENABLE();
	  GPIO_InitTypeDef GPIO_InitStruct = {0};
	  GPIO_InitStruct.Pin = AnSel1_Pin|AnSel0_Pin;
	  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	  GPIO_InitStruct.Pull = GPIO_NOPULL;
	  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	  HAL_GPIO_Init(AnSel0_GPIO_Port, &GPIO_InitStruct);
}
