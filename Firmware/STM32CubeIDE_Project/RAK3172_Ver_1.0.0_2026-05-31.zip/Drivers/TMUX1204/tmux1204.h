/*
 * tmux1204.h
 *
 *  Created on: 12 mar 2026
 *      Author: L
 */

#ifndef TMUX1204_TMUX1204_H_
#define TMUX1204_TMUX1204_H_

#include "main.h"

#define ANALOG_SEL0_PORT   AnSel0_GPIO_Port
#define ANALOG_SEL0_PIN    AnSel0_Pin

#define ANALOG_SEL1_PORT   AnSel1_GPIO_Port
#define ANALOG_SEL1_PIN    AnSel1_Pin

// -----------------------------
// Tipi
// -----------------------------
typedef enum
{
    Analog0 = 0,
    Analog1 = 1,
    Analog2 = 2,
    Analog3 = 3
} Analog_Input_t;

// -----------------------------
// Funzioni
// -----------------------------
void analog_mux_select_input(Analog_Input_t input);

void analog_mux_LowPower();

void analog_mux_ExitLowPower();


#endif /* TMUX1204_TMUX1204_H_ */
