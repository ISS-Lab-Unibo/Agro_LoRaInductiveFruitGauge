/*
 * sel74hc151.c
 *
 *  Created on: 12 mar 2026
 *      Author: L
 */

#include "sel74hc151.h"

void hc151_select_input(HC151_Input_t input)
{
    // Bit 0 = A, Bit 1 = B, Bit 2 = C
    HAL_GPIO_WritePin(HC151_PIN_A_PORT, HC151_PIN_A_PIN, (input & 0x01) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(HC151_PIN_B_PORT, HC151_PIN_B_PIN, (input & 0x02) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(HC151_PIN_C_PORT, HC151_PIN_C_PIN, (input & 0x04) ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

// disattiva le GPIO del microcontrollore in modo che le resistenze di PU selezionino il canale 3
void hc151_mux_LowPower()
{
	hc151_select_input(SelCH7InputPinze);
//	GPIO_Analog_LP(HC151_PIN_A_PORT, HC151_PIN_A_PIN|HC151_PIN_B_PIN|HC151_PIN_C_PIN);
}

void hc151_mux_ExitLowPower()
{
	  __HAL_RCC_GPIOC_CLK_ENABLE();
	  GPIO_InitTypeDef GPIO_InitStruct = {0};
	  GPIO_InitStruct.Pin = HC151_PIN_A_PIN|HC151_PIN_B_PIN|HC151_PIN_C_PIN;
	  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	  GPIO_InitStruct.Pull = GPIO_NOPULL;
	  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	  HAL_GPIO_Init(HC151_PIN_A_PORT, &GPIO_InitStruct);
}
