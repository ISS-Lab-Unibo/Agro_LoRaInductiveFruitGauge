/*
 * sel74hc151.h
 *
 *  Created on: 12 mar 2026
 *      Author: L
 */

#ifndef SEL74HC151_SEL74HC151_H_
#define SEL74HC151_SEL74HC151_H_

#include "main.h"

#define HC151_PIN_A_PORT   CTRLA_GPIO_Port
#define HC151_PIN_A_PIN    CTRLA_Pin

#define HC151_PIN_B_PORT   CTRLB_GPIO_Port
#define HC151_PIN_B_PIN    CTRLB_Pin

#define HC151_PIN_C_PORT   CTRLC_GPIO_Port
#define HC151_PIN_C_PIN    CTRLC_Pin


typedef enum
{
    SelCH0InputPinze = 0,
    SelCH1InputPinze = 1,
    SelCH2InputPinze = 2,
    SelCH3InputPinze = 3,
    SelCH4InputPinze = 4,
    SelCH5InputPinze = 5,
    SelCH6InputPinze = 6,
    SelCH7InputPinze = 7
} HC151_Input_t;


void hc151_select_input(HC151_Input_t input);
void hc151_mux_LowPower();
void hc151_mux_ExitLowPower();


#endif /* SEL74HC151_SEL74HC151_H_ */
