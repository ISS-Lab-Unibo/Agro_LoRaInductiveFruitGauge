/*
 * pinzeFunctions.h
 *
 *  Created on: 22 mag 2026
 *      Author: L
 */

#ifndef PINZEFUNCTIONS_PINZEFUNCTIONS_H_
#define PINZEFUNCTIONS_PINZEFUNCTIONS_H_

#include "stdint.h"
#include "stdbool.h"
#include "LoRaNodeConfig.h"
#include "sent.h"
#include "cube_spline.h"

#define DEG_TO_RAD(angle_deg) ((double)(angle_deg) * M_PI / 180.0)


void leggiBatterie(uint16_t *battVoltage, uint16_t *backupBattVoltage, bool verboso);
void AppendFloatToBuffer100(float value, uint32_t *index, uint8_t *buffer);
void AppendFloatToBuffer100(float value, uint32_t *index, uint8_t *buffer);
void AppendiUint16ToBuffer10(uint16_t value, uint32_t *index, uint8_t *buffer);


void tutteLetture(float *mediaPinzeRaw, float *DEVstdPinzeRaw, uint16_t *ADCvalues, uint16_t *VRef, float *temperature, float *diameter);

void PrintADCVoltages(uint16_t *VAdc, uint16_t *Vref);
void PrintPinzaStatistics(float *media, float *DEVstd, float *temperatura, float *diameter, uint8_t maxNumPinze);
void PrintVariablesSize();
void TCompensazioneTermicaPinze( float *temperature, float Tref, uint16_t N, configurazionePinze_t *cfg, float *radiusPlier_out, float *lClamp_out);


void inizializzaArrayAZero_float_UTILS(float* array, size_t lunghezza);

void interpolazioneAngolo(S *coeffs, uint8_t Num_elementi, const float *vals, float *risultati);


#endif /* PINZEFUNCTIONS_PINZEFUNCTIONS_H_ */


