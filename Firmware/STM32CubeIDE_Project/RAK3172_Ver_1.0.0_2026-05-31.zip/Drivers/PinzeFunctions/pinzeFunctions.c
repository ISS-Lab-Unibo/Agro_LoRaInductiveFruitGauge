/*
 * pinzeFunctions.c
 *
 *  Created on: 22 mag 2026
 *      Author: L
 */

#include "pinzeFunctions.h"
#include "GPIOSet.h"
#include "BatterySensing.h"
#include "i2c.h"
#include "tca9534.h"
#include "sel74hc151.h"
#include "sys_app.h"
#include "stdio.h"
#include "ADCGeneric.h"
#include "math.h"

extern configurazioni_t config;
extern S calibCoefficients[MAX_NUM_PINZE];


void leggiBatterie(uint16_t *battVoltage, uint16_t *backupBattVoltage, bool verboso)
{
	uint16_t internal, external;
	readBatteryVoltage(&external, &internal);
	if (verboso == true)
	{
		APP_LOG( TS_OFF, VLEVEL_M, "-----------LETTURA TENSIONE BATTERIA E BACKUP----------\n\r");
		HAL_Delay(5);
		APP_LOG( TS_OFF, VLEVEL_M, "Batteria principale ADC %d\n\r", external);
		HAL_Delay(5);
		APP_LOG( TS_OFF, VLEVEL_M, "Batteria backup ADC %d\n\r", internal);
		HAL_Delay(5);
		APP_LOG( TS_OFF, VLEVEL_M, "---------------\n\r\n\r");
		HAL_Delay(100);
	}
	*battVoltage = external;
	*backupBattVoltage = internal;
}

/*
 * qui si inserisce il valore in float da convertire in intero senza segno, lo si moltiplica per 100, se ne prende la parte intera e lo si spezza in LSB e MSB, da appendere all'array
 */
void AppendFloatToBuffer100(float value, uint32_t *index, uint8_t *buffer)
{
	/* Moltiplica per 100 e prende la parte intera */
	uint16_t convertito = (uint16_t)(value * 100.0f);

	/* LSB */
	buffer[*index] = (uint8_t)(convertito & 0xFF);
	(*index)++;

	/* MSB */
	buffer[*index] = (uint8_t)((convertito >> 8) & 0xFF);
	(*index)++;
}

/*
 * qui si inserisce il valore in float da convertire in intero, lo si moltiplica per 10, se ne prende la parte intera e lo si spezza in LSB e MSB, da appendere all'array
 */
void AppendFloatToBuffer10(float value, uint32_t *index, uint8_t *buffer)
{
	/* Moltiplica per 100 e prende la parte intera */
	uint16_t convertito = (uint16_t)(value * 10.0f);

	/* LSB */
	buffer[*index] = (uint8_t)(convertito & 0xFF);
	(*index)++;

	/* MSB */
	buffer[*index] = (uint8_t)((convertito >> 8) & 0xFF);
	(*index)++;
}

/*
 * qui si inserisce il valore in uint16_t da convertire in intero, lo si moltiplica per 10, se ne prende la parte intera e lo si spezza in LSB e MSB, da appendere all'array
 */
void AppendiUint16ToBuffer10(uint16_t value, uint32_t *index, uint8_t *buffer)
{
	/* Moltiplica per 100 e prende la parte intera */
	uint16_t convertito = (value * 10.0);

	/* LSB */
	buffer[*index] = (uint8_t)(convertito & 0xFF);
	(*index)++;

	/* MSB */
	buffer[*index] = (uint8_t)((convertito >> 8) & 0xFF);
	(*index)++;
}

void PrintADCVoltages(uint16_t *VAdc, uint16_t *Vref)
{
	for(uint8_t i = 0; i < 4; i++)
	{
		APP_LOG( TS_OFF, VLEVEL_M, "Tensioni lette da ADC ch %d: ingresso: %d Vref: %d\n\r", i, VAdc[i], Vref[i] );
	}
	APP_LOG( TS_OFF, VLEVEL_M, "######### ---------#########\n\r");
}

void PrintPinzaStatistics(float *media, float *DEVstd, float *temperatura, float *diameter, uint8_t maxNumPinze)
{
	for(uint8_t i = 0; i < maxNumPinze; i++)
	{
		char scritte[100];
		sprintf(scritte, "Pinza %d:\t media = %4.2f,\t DevSTD = %4.2f temperatura = %4.2f diametro = %4.2f\n\r", i, media[i], DEVstd[i], temperatura[i], diameter[i]);
		APP_LOG(TS_OFF, VLEVEL_M, "%s", scritte);
	}
}

void PrintVariablesSize()
{
	HAL_Delay(20);
	APP_LOG( TS_OFF, VLEVEL_M, "\n\r\n\r-----------DIMENSIONE VARIABILI----------\n\r");
	HAL_Delay(5);
	APP_LOG( TS_OFF, VLEVEL_M, "float %d \n\r", sizeof(float));
	HAL_Delay(5);
	APP_LOG( TS_OFF, VLEVEL_M, "bool %d \n\r", sizeof(bool));
	HAL_Delay(5);
	APP_LOG( TS_OFF, VLEVEL_M, "uint8_t %d \n\r", sizeof(uint8_t));
	HAL_Delay(5);
	APP_LOG( TS_OFF, VLEVEL_M, "uint16_t %d \n\r", sizeof(uint16_t));
	HAL_Delay(5);
	APP_LOG( TS_OFF, VLEVEL_M, "configurazionePinze_t %d \n\r", sizeof(configurazionePinze_t));
	HAL_Delay(5);
	APP_LOG( TS_OFF, VLEVEL_M, "configurazioneAnalogSensor_t %d \n\r", sizeof(configurazioneAnalogSensor_t));
	HAL_Delay(5);
	APP_LOG( TS_OFF, VLEVEL_M, "LoRaConfig %d \n\r", sizeof(LoRaConfigABP_t));
	HAL_Delay(5);
	APP_LOG( TS_OFF, VLEVEL_M, "configurazioni_t %d \n\r", sizeof(configurazioni_t));
	HAL_Delay(5);
}

void TCompensazioneTermicaPinze( float *temperature, float Tref, uint16_t N, configurazionePinze_t *cfg, float *radiusPlier_out, float *lClamp_out)
{
	for(uint16_t i = 0; i < N; i++)
	{
		if(cfg[i].tempCompensationActive == true)
		{
			float deltaT = temperature[i] - Tref;

			/* lambda è in 10^-6 /K , quindi devo effettuare ua conversione */
			float k_pl = cfg[i].lambdaPlier * 1e-6f;
			float k_cl = cfg[i].lambdaClamp * 1e-6f;

			radiusPlier_out[i] = cfg[i].radiusPlier * (1.0f + k_pl * deltaT);
			lClamp_out[i] = cfg[i].lClamp * (1.0f + k_cl * deltaT);
		}
		else
		{
			/* nessuna compensazione */
			radiusPlier_out[i] = cfg[i].radiusPlier;
			lClamp_out[i]      = cfg[i].lClamp;
		}
	}
}

void inizializzaArrayAZero_float_UTILS(float* array, size_t lunghezza) {
	for (size_t i = 0; i < lunghezza; i++) {
		array[i] = 0;
	}
}

void tutteLetture(float *mediaPinzeRaw, float *DEVstdPinzeRaw, uint16_t *ADCvalues, uint16_t *VRef, float *temperature, float *diameter)
{
	uint8_t ledGiaAcceso = 0;
	// se il eld è già acceso, non stiamo a riaccenderlo ma ricordiamoci del suo statato precedente
	if (readStatusled() == POWER_ON)
		ledGiaAcceso = 1;
	else
		accendiLed();

	//	temperature[] = {25, 25, 25, 25, 25, 25, 25, 25};
	/* -------------- lettura dalle pinze ---------------*/
	//Qui escono i valri RAW
	lettureSent(config.configurazionePinze, mediaPinzeRaw, DEVstdPinzeRaw, temperature, false);

	float angolo[MAX_NUM_PINZE];
	// effettuiamo l'interpolazione dell'angolo, entrano valori RAW ed escono valori espressi in deg
	interpolazioneAngolo(calibCoefficients, MAX_NUM_PINZE, mediaPinzeRaw, angolo);

	float lClamp_compensated[MAX_NUM_PINZE];
	// se necessario effettuo la compensazione termica delle lunghezze
	float radiusPlier_compensated[MAX_NUM_PINZE];
	inizializzaArrayAZero_float_UTILS(radiusPlier_compensated, MAX_NUM_PINZE);
	inizializzaArrayAZero_float_UTILS(lClamp_compensated, MAX_NUM_PINZE);
	inizializzaArrayAZero_float_UTILS(diameter, MAX_NUM_PINZE);
	TCompensazioneTermicaPinze(temperature, 25.0f, MAX_NUM_PINZE, config.configurazionePinze, radiusPlier_compensated, lClamp_compensated);

	// a partire dall'angolo troviamo il la distanza tra i fulcri delle "manine" dei due bracci
	for (uint8_t i = 0; i<MAX_NUM_PINZE; i++)
	{
		diameter[i] = 2.0f * radiusPlier_compensated[i] * (float)sin(DEG_TO_RAD(angolo[i]));
		diameter[i] = diameter[i] - 2*lClamp_compensated[i];
	}

	/* -------------- lettura ingressi analogici ---------------*/
	readAllChannels(config.configurazioneAnalogSensor, ADCvalues, VRef);

	// fine di tutto
	// se il led era già acceso, lasciamolo tale, altrimenti spegniamolo
	if (ledGiaAcceso != 1)
		spegniLed();
}

void interpolazioneAngolo(S *coeffs, uint8_t Num_elementi, const float *vals, float *risultati)
{
    for (uint8_t i = 0; i < Num_elementi; i++) {
        evaluate(&coeffs[i], vals[i], &risultati[i]);
    }
}

