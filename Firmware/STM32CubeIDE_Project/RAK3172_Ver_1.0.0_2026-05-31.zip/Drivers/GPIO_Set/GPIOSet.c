/*
 * GPIOSet.c
 *
 *  Created on: 10 feb 2026
 *      Author: L
 */

#include "gpio.h"
#include "GPIOSet.h"
#include "stm32wlxx_hal.h"
#include "main.h"

void GPIO_Analog_LP(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};

	/* Modalità analogica = minimo consumo */
	GPIO_InitStruct.Pin   = GPIO_Pin;
	GPIO_InitStruct.Mode  = GPIO_MODE_ANALOG;
	GPIO_InitStruct.Pull  = GPIO_NOPULL;          // obbligatorio
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;  // irrilevante ma sicuro

	HAL_GPIO_Init(GPIOx, &GPIO_InitStruct);
}

void GPIO_Configure_DigOut(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};

	/* Modalità analogica = minimo consumo */
	GPIO_InitStruct.Pin   = GPIO_Pin;
	GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull  = GPIO_NOPULL;          // obbligatorio
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;  // irrilevante ma sicuro

	HAL_GPIO_Init(GPIOx, &GPIO_InitStruct);
}

void accendiLed()
{
	__HAL_RCC_GPIOB_CLK_ENABLE();
	GPIO_Configure_DigOut(indicatore_GPIO_Port, indicatore_Pin);
	HAL_GPIO_WritePin(indicatore_GPIO_Port, indicatore_Pin, GPIO_PIN_SET);
}

PowerState_t readStatusled()
{
	if (HAL_GPIO_ReadPin(indicatore_GPIO_Port, indicatore_Pin) == GPIO_PIN_SET)
		return POWER_ON;
	else
		return POWER_OFF;
}

void spegniLed()
{
	HAL_GPIO_WritePin(indicatore_GPIO_Port, indicatore_Pin, GPIO_PIN_RESET);
	GPIO_Analog_LP(indicatore_GPIO_Port, indicatore_Pin);
}


void powerStages(PowerStage_t stages, PowerState_t state)
{
	GPIO_PinState gpioState = (state == POWER_ON) ? GPIO_PIN_SET : GPIO_PIN_RESET;

	if (stages & POWER_STAGE_BOOST_ON_PINZE)
	{
		HAL_GPIO_WritePin(BoostOnPinze_GPIO_Port, BoostOnPinze_Pin, gpioState);
		if (state ==  POWER_ON)
			GPIO_Configure_DigOut(BoostOnPinze_GPIO_Port, BoostOnPinze_Pin);
		else
			GPIO_Analog_LP(BoostOnPinze_GPIO_Port, BoostOnPinze_Pin);
	}

	if (stages & POWER_STAGE_PINZE_ON)
	{
		HAL_GPIO_WritePin(PinzeOn_GPIO_Port, PinzeOn_Pin, gpioState);
		if (state ==  POWER_ON)
			GPIO_Configure_DigOut(PinzeOn_GPIO_Port, PinzeOn_Pin);
		else
			GPIO_Analog_LP(PinzeOn_GPIO_Port, PinzeOn_Pin);
	}

	if (stages & POWER_STAGE_VSTORAGE)
	{
		HAL_GPIO_WritePin(VStorage_GPIO_Port, VStorage_Pin, gpioState);
		if (state ==  POWER_ON)
			GPIO_Configure_DigOut(VStorage_GPIO_Port, VStorage_Pin);
		else
			GPIO_Analog_LP(VStorage_GPIO_Port, VStorage_Pin);
	}

	if (stages & POWER_STAGE_ANSEL1)
		HAL_GPIO_WritePin(AnSel1_GPIO_Port, AnSel1_Pin, gpioState);

	if (stages & POWER_STAGE_VSTORAGE_READ_ACT)
	{
		HAL_GPIO_WritePin(VStorageReadActivate_GPIO_Port, VStorageReadActivate_Pin, gpioState);
		if (state ==  POWER_ON)
			GPIO_Configure_DigOut(VStorageReadActivate_GPIO_Port, VStorageReadActivate_Pin);
		else
			GPIO_Analog_LP(VStorageReadActivate_GPIO_Port, VStorageReadActivate_Pin);
	}

	if (stages & POWER_STAGE_CTRLB)
		HAL_GPIO_WritePin(CTRLB_GPIO_Port, CTRLB_Pin, gpioState);

	if (stages & POWER_STAGE_CTRLA)
		HAL_GPIO_WritePin(CTRLA_GPIO_Port, CTRLA_Pin, gpioState);

	if (stages & POWER_STAGE_INDICATORE)
	{
		HAL_GPIO_WritePin(indicatore_GPIO_Port, indicatore_Pin, gpioState);
		if (state ==  POWER_ON)
			GPIO_Configure_DigOut(indicatore_GPIO_Port, indicatore_Pin);
		else
			GPIO_Analog_LP(indicatore_GPIO_Port, indicatore_Pin);
	}

	if (stages & POWER_STAGE_ANSEL0)
		HAL_GPIO_WritePin(AnSel0_GPIO_Port, AnSel0_Pin, gpioState);

	if (stages & POWER_STAGE_ANALOG_POWERIN)
		HAL_GPIO_WritePin(AnalogPowerIN_GPIO_Port, AnalogPowerIN_Pin, gpioState);
	{
		if (state ==  POWER_ON)
			GPIO_Configure_DigOut(AnalogPowerIN_GPIO_Port, AnalogPowerIN_Pin);
		else
			GPIO_Analog_LP(AnalogPowerIN_GPIO_Port, AnalogPowerIN_Pin);
	}// nuovo
}

PowerState_t readPowerStage(PowerStage_t stage)
{
	if (stage & POWER_STAGE_BOOST_ON_PINZE)
		return (HAL_GPIO_ReadPin(BoostOnPinze_GPIO_Port, BoostOnPinze_Pin) == GPIO_PIN_SET) ? POWER_ON : POWER_OFF;

	if (stage & POWER_STAGE_PINZE_ON)
		return (HAL_GPIO_ReadPin(PinzeOn_GPIO_Port, PinzeOn_Pin) == GPIO_PIN_SET) ? POWER_ON : POWER_OFF;

	if (stage & POWER_STAGE_VSTORAGE)
		return (HAL_GPIO_ReadPin(VStorage_GPIO_Port, VStorage_Pin) == GPIO_PIN_SET) ? POWER_ON : POWER_OFF;

	if (stage & POWER_STAGE_ANSEL1)
		return (HAL_GPIO_ReadPin(AnSel1_GPIO_Port, AnSel1_Pin) == GPIO_PIN_SET) ? POWER_ON : POWER_OFF;

	if (stage & POWER_STAGE_VSTORAGE_READ_ACT)
		return (HAL_GPIO_ReadPin(VStorageReadActivate_GPIO_Port, VStorageReadActivate_Pin) == GPIO_PIN_SET) ? POWER_ON : POWER_OFF;

	if (stage & POWER_STAGE_CTRLB)
		return (HAL_GPIO_ReadPin(CTRLB_GPIO_Port, CTRLB_Pin) == GPIO_PIN_SET) ? POWER_ON : POWER_OFF;

	if (stage & POWER_STAGE_CTRLA)
		return (HAL_GPIO_ReadPin(CTRLA_GPIO_Port, CTRLA_Pin) == GPIO_PIN_SET) ? POWER_ON : POWER_OFF;

	if (stage & POWER_STAGE_INDICATORE)
		return (HAL_GPIO_ReadPin(indicatore_GPIO_Port, indicatore_Pin) == GPIO_PIN_SET) ? POWER_ON : POWER_OFF;

	if (stage & POWER_STAGE_ANSEL0)
		return (HAL_GPIO_ReadPin(AnSel0_GPIO_Port, AnSel0_Pin) == GPIO_PIN_SET) ? POWER_ON : POWER_OFF;

	if (stage & POWER_STAGE_ANALOG_POWERIN)
		return (HAL_GPIO_ReadPin(AnalogPowerIN_GPIO_Port, AnalogPowerIN_Pin) == GPIO_PIN_SET) ? POWER_ON : POWER_OFF;

	// Se stage = NONE o non gestito
	return POWER_OFF;
}

