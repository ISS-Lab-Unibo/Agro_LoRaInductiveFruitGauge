/*
 * GPIOSet.h
 *
 *  Created on: 10 feb 2026
 *      Author: L
 */

#ifndef GPIO_SET_GPIOSET_H_
#define GPIO_SET_GPIOSET_H_

#include "stm32wlxx_hal.h"

typedef enum
{
    POWER_OFF = 0,
    POWER_ON  = 1
} PowerState_t;

typedef enum
{
    POWER_STAGE_NONE              = 0x00,
    POWER_STAGE_BOOST_ON_PINZE    = 0x01,
    POWER_STAGE_PINZE_ON          = 0x02,
    POWER_STAGE_VSTORAGE          = 0x04,
    POWER_STAGE_ANSEL1            = 0x08,
    POWER_STAGE_VSTORAGE_READ_ACT = 0x10,
    POWER_STAGE_CTRLB             = 0x20,
    POWER_STAGE_CTRLA             = 0x40,
    POWER_STAGE_INDICATORE        = 0x80,
    POWER_STAGE_ANSEL0            = 0x100,
    POWER_STAGE_ANALOG_POWERIN    = 0x200  // nuovo pin
} PowerStage_t;

/* Prototipi */
void powerStages(PowerStage_t stages, PowerState_t state);
PowerState_t readPowerStage(PowerStage_t stage);

void GPIO_Analog_LP(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin);
void accendiLed();
void spegniLed();
PowerState_t readStatusled();



#endif /* GPIO_SET_GPIOSET_H_ */
