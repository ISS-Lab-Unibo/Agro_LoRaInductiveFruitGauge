#ifndef TCA9634_TCA9534_H
#define TCA9634_TCA9534_H


#define TCA9534_INPUT_REG   0b00
#define TCA9534_OUTPUT_REG  0b01
#define TCA9534_POLINV_REG  0b10
#define TCA9534_CONFIG_REG  0b11

#include <stdbool.h>
//#include <stdint.h>
#include "main.h"
#include "i2c.h"

#define TCA9534_ADDR_A2A1A0_000   0x20
#define TCA9534_ADDR_A2A1A0_001   0x21
#define TCA9534_ADDR_A2A1A0_010   0x22
#define TCA9534_ADDR_A2A1A0_011   0x23
#define TCA9534_ADDR_A2A1A0_100   0x24
#define TCA9534_ADDR_A2A1A0_101   0x25
#define TCA9534_ADDR_A2A1A0_110   0x26
#define TCA9534_ADDR_A2A1A0_111   0x27

typedef enum
{
    TCA9534_PINZA0 = (1 << 0),
    TCA9534_PINZA1 = (1 << 1),
    TCA9534_PINZA2 = (1 << 2),
    TCA9534_PINZA3 = (1 << 3),
    TCA9534_PINZA4 = (1 << 4),
    TCA9534_PINZA5 = (1 << 5),
    TCA9534_PINZA6 = (1 << 6),
    TCA9534_PINZA7 = (1 << 7)
} TCA9534_Pinza_t;

typedef enum
{
    TCA9534_POL_NON_INVERTITA = 0,  // normale, 0=low fisico = 0 logico
    TCA9534_POL_INVERTITA     = 1   // invertita, 0=high fisico = 0 logico
} TCA9534_Polarity_t;

typedef enum
{
    TCA9534_DIR_OUTPUT = 0,   // bit a 0 = output
    TCA9534_DIR_INPUT  = 1    // bit a 1 = input
} TCA9534_Direction_t;

typedef enum
{
    TCA9534_SPENTO = 0,
    TCA9534_ACCESO = 1
} TCA9534_Stato_t;

typedef struct {
	I2C_HandleTypeDef* i2c;
    uint8_t addr;
    uint32_t op_timeout;
    uint8_t last_output_state;
} expander_t;

// initialise an expander_t struct
void expander_init(expander_t* exp, I2C_HandleTypeDef* i2c, uint8_t addr, uint32_t op_timeout);

// read the expander's input pin state
bool expander_read_inputs(expander_t* exp, uint8_t* pin_state);

// sets the expander's output pin state
bool expander_write_outputs(expander_t* exp, uint8_t output_state);

// configure the expander's input/output directions (1 is input, 0 is output)
bool expander_set_pin_directions(expander_t* exp, uint8_t directions);

// configure the expander's pin polarities (1 inverts polarity)
bool expander_set_pin_polarities(expander_t* exp, uint8_t polarities);


// low-level function for reading the value of an i²c register
bool i2c_read_reg(I2C_HandleTypeDef* i2c, uint8_t dev_addr, uint8_t reg_id, uint8_t* dest, uint8_t num_bytes, uint32_t timeout_us);

// low-level function for writing to an i²c register
bool i2c_write_reg(I2C_HandleTypeDef* i2c, uint8_t dev_addr, uint8_t reg_id, uint8_t* buf , uint8_t num_bytes, uint32_t timeout_us);

bool expander_write_pinze(expander_t* exp, uint8_t pinze_mask, TCA9534_Stato_t stato);

bool expander_set_pinze_polarita_mask(expander_t* exp, uint8_t pinze_mask, TCA9534_Polarity_t polarita);

bool expander_set_pinze_direzione_mask(expander_t* exp, uint8_t pinze_mask, TCA9534_Direction_t direzione);

#endif /* TCA9534_H */

