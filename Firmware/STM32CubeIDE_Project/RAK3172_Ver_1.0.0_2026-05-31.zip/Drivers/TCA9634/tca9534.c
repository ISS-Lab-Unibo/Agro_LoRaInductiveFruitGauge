#include "tca9534.h"

expander_t expanderI2C;

void expander_ERROR(HAL_StatusTypeDef errore)
{
	HAL_Delay(1000);
}

void expander_init(expander_t* exp, I2C_HandleTypeDef* i2c, uint8_t addr, uint32_t op_timeout) {
	exp->i2c = i2c;
	exp->addr = addr<<1;
	exp->op_timeout = op_timeout;
	exp->last_output_state = 0;

	// questo millisecondo serve perchè il chip expander I2C abbia il tempo epr essere alimentato correttamente
	// vedi "StadioPinzeON_VS_OUT_SWITCH.psdata
	// poi c'è ancheil tempo per cui la 5V sia efefttivamente attiva, qui guarda la "StadioPinzeON_VS_5V.psdata"
	HAL_Delay(1);
	expander_set_pinze_direzione_mask(&expanderI2C, TCA9534_PINZA0 |TCA9534_PINZA1 | TCA9534_PINZA2 |TCA9534_PINZA3 | TCA9534_PINZA4 | TCA9534_PINZA5 |TCA9534_PINZA6 | TCA9534_PINZA7, TCA9534_DIR_OUTPUT);
	expander_set_pinze_polarita_mask(&expanderI2C, TCA9534_PINZA0 |TCA9534_PINZA1 | TCA9534_PINZA2 |TCA9534_PINZA3 | TCA9534_PINZA4 | TCA9534_PINZA5 |TCA9534_PINZA6 | TCA9534_PINZA7, TCA9534_POL_NON_INVERTITA);
	expander_write_pinze(&expanderI2C, TCA9534_PINZA0 |TCA9534_PINZA1 | TCA9534_PINZA2 |TCA9534_PINZA3 | TCA9534_PINZA4 | TCA9534_PINZA5 |TCA9534_PINZA6 | TCA9534_PINZA7, TCA9534_SPENTO);
}

bool expander_read_inputs(expander_t* exp, uint8_t* pin_state) {
	return i2c_read_reg(exp->i2c, exp->addr, TCA9534_INPUT_REG, pin_state, 1, exp->op_timeout);
}

bool expander_set_pin_directions(expander_t* exp, uint8_t directions) {
	return i2c_write_reg(exp->i2c, exp->addr, TCA9534_CONFIG_REG, &directions, 1, exp->op_timeout);
}

bool expander_set_pin_polarities(expander_t* exp, uint8_t polarities) {
	return i2c_write_reg(exp->i2c, exp->addr, TCA9534_POLINV_REG, &polarities, 1, exp->op_timeout);
}

bool expander_read_outputs(expander_t* exp, uint8_t* output_state) {
	return i2c_read_reg(exp->i2c, exp->addr, TCA9534_OUTPUT_REG, output_state, 1, exp->op_timeout);
}

bool expander_write_outputs(expander_t* exp, uint8_t output_state) {
	if (i2c_write_reg(exp->i2c, exp->addr, TCA9534_OUTPUT_REG, &output_state, 1, exp->op_timeout)) {
		exp->last_output_state = output_state;
		return true;
	} else {
		return false;
	}
}

bool i2c_write_reg(I2C_HandleTypeDef* i2c, uint8_t dev_addr, uint8_t reg_id, uint8_t* src , uint8_t num_bytes, uint32_t timeout_us) {
	if (num_bytes > 8) {
		return false;
	}
	HAL_StatusTypeDef ret = HAL_I2C_Mem_Write(i2c, dev_addr, reg_id, I2C_MEMADD_SIZE_8BIT, src, num_bytes, timeout_us);
	if (ret != HAL_OK)
	{
		expander_ERROR(HAL_OK);
	}
	return (ret == num_bytes + 1);
}

bool i2c_read_reg(I2C_HandleTypeDef* i2c, uint8_t dev_addr, uint8_t reg_id, uint8_t* dest, uint8_t num_bytes, uint32_t timeout_us) {
	HAL_StatusTypeDef ret = HAL_I2C_Mem_Read(i2c, dev_addr, (uint8_t)reg_id, I2C_MEMADD_SIZE_8BIT, dest, num_bytes ,timeout_us);
	if (ret != HAL_OK) {
		expander_ERROR(ret);
		return false;
	}
	return true;
}

bool expander_write_pinze(expander_t* exp, uint8_t pinze_mask, TCA9534_Stato_t stato)
{
	uint8_t new_state = exp->last_output_state;

	if (stato == TCA9534_ACCESO)
	{
		new_state |= pinze_mask;    // accende tutte le pinze specificate
	}
	else // TCA9534_SPENTO
	{
		new_state &= ~pinze_mask;   // spegne tutte le pinze specificate
	}

	return expander_write_outputs(exp, new_state);
}

//bool expander_set_pinza_polarity(expander_t* exp, TCA9534_Pinza_t pinza, TCA9534_Polarity_t polarity)
//{
//    uint8_t pol_state;
//    if (!expander_read_inputs(exp, &pol_state)) return false;
//
//    if (polarity == TCA9534_POL_INVERTITA)
//        pol_state |= pinza;
//    else
//        pol_state &= ~pinza;
//
//    return expander_set_pin_polarities(exp, pol_state);
//}
//
//bool expander_set_pinza_direction(expander_t* exp, TCA9534_Pinza_t pinza, TCA9534_Direction_t dir)
//{
//    uint8_t dir_state;
//    if (!expander_read_inputs(exp, &dir_state)) return false;
//
//    if (dir == TCA9534_DIR_INPUT)
//        dir_state |= pinza;
//    else
//        dir_state &= ~pinza;
//
//    return expander_set_pin_directions(exp, dir_state);
//}

bool expander_set_pinze_polarita_mask(expander_t* exp, uint8_t pinze_mask, TCA9534_Polarity_t polarita)
{
	uint8_t pol_state;

	// Legge lo stato attuale dei registri polarità
	if (!expander_read_inputs(exp, &pol_state))
		return false;

	if (polarita == TCA9534_POL_INVERTITA)
		pol_state |= pinze_mask;    // imposta tutti i bit a 1 = invertita
	else
		pol_state &= ~pinze_mask;   // imposta tutti i bit a 0 = non invertita

	return expander_set_pin_polarities(exp, pol_state);
}

bool expander_set_pinze_direzione_mask(expander_t* exp, uint8_t pinze_mask, TCA9534_Direction_t direzione)
{
	uint8_t dir_state;

	// Legge lo stato attuale dei registri direzione
	if (!expander_read_inputs(exp, &dir_state))
		return false;

	if (direzione == TCA9534_DIR_INPUT)
		dir_state |= pinze_mask;    // imposta tutti i bit a 1 = input
	else
		dir_state &= ~pinze_mask;   // imposta tutti i bit a 0 = output

	return expander_set_pin_directions(exp, dir_state);
}

