#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import re
import shutil
from pathlib import Path
from datetime import datetime
import zipfile


def read_version(app_version_file):
    """Legge i tre numeri di versione da app_version.h"""

    text = app_version_file.read_text(encoding="utf-8")

    patterns = {
        "main": r"#define\s+APP_VERSION_MAIN\s+\(0x([0-9A-Fa-f]+)U\)",
        "sub1": r"#define\s+APP_VERSION_SUB1\s+\(0x([0-9A-Fa-f]+)U\)",
        "sub2": r"#define\s+APP_VERSION_SUB2\s+\(0x([0-9A-Fa-f]+)U\)",
    }

    values = {}

    for key, pattern in patterns.items():
        match = re.search(pattern, text)
        if not match:
            raise RuntimeError(
                f"Impossibile trovare {key} in {app_version_file}"
            )

        # converte il valore esadecimale in decimale
        values[key] = int(match.group(1), 16)

    return values["main"], values["sub1"], values["sub2"]

def add_to_zip(zipf, path: Path, project_root: Path):
    if path.is_dir():
        for file in path.rglob("*"):
            if file.is_file():
                zipf.write(file, file.relative_to(project_root))
    elif path.exists():
        zipf.write(path, path.relative_to(project_root))

def main():

    # Cartella root del progetto
    project_root = Path(__file__).resolve().parent

    debug_dir = project_root / "Debug"
    source_hex = debug_dir / "RAK3172.hex"

    if not source_hex.exists():
        raise FileNotFoundError(
            f"File HEX non trovato: {source_hex}"
        )

    version_file = (
        project_root
        / "LoRaWan"
        / "App"
        / "app_version.h"
    )

    if not version_file.exists():
        raise FileNotFoundError(
            f"File non trovato: {version_file}"
        )

    major, minor, patch = read_version(version_file)

    output_dir = project_root / "HEX file"
    output_dir.mkdir(exist_ok=True)
    
    for old_hex in output_dir.glob("*.hex"):
        try:
            old_hex.unlink()
            print(f"Eliminato: {old_hex.name}")
        except Exception as e:
            print(f"Errore eliminando {old_hex.name}: {e}")

    today = datetime.now().strftime("%Y-%m-%d")

    dest_name = (
        f"RAK3172_Ver_{major}.{minor}.{patch}_{today}.hex"
    )

    dest_file = output_dir / dest_name

    shutil.copy2(source_hex, dest_file)

    print(f"HEX copiato:")
    print(f"  Origine : {source_hex}")
    print(f"  Destin. : {dest_file}")
    
    # --- CREAZIONE ARCHIVIO ZIP IN ROOT ---
    
    zip_path = project_root / dest_file.with_suffix(".zip").name
    items_to_include = [
    "calibFiles",
    "Core",
    "Drivers",
    "LoRaWan",
    "Middlewares",
    "Utilities",
    "RAK3172.ioc",
    ".cproject",
    ".mxproject",
    ".project",
    "STM32WLE5JCIX_FLASH.ld",
    "post_build_hex.py",
    ]
    
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
        for item in items_to_include:
            p = project_root / item
            add_to_zip(zipf, p, project_root)

    print()
    print(f"ZIP creato nella root:")
    print(f"  {zip_path}")

if __name__ == "__main__":
    main()