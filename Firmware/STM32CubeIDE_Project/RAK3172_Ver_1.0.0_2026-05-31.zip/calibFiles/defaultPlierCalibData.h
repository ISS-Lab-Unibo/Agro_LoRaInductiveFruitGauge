/*
 * defaultPlierCalibData.h
 *
 *  Created on: 27 mag 2026
 *      Author: L
 */

#ifndef DEFAULTPLIERCALIBDATA_H_
#define DEFAULTPLIERCALIBDATA_H_

#include "cube_spline.h"
#include "LoRaNodeConfig.h"


/*
 * qui il valore letto da pinza
 */
float X[] = {
    943, 998, 1060, 1135, 1216, 1303, 1389, 1472,
    1552, 1626, 1697, 1764, 1830, 1892, 1957, 2018,
    2078, 2141, 2205, 2273, 2341, 2413, 2490, 2573,
    2659, 2752, 2843, 2935, 3025, 3104, 3181, 3251,
    3116
};

/*
 * qui l'angolo che ci aspettiamo
 */
float Y[] = {
    11.96, 14.36, 16.77, 19.19, 21.61, 24.05, 26.50, 28.96,
    31.43, 33.92, 36.42, 38.94, 41.48, 44.05, 46.64, 49.25,
    51.89, 54.56, 57.26, 60.00, 62.78, 65.59, 68.46, 71.37,
    74.34, 77.36, 80.46, 83.62, 86.87, 90.20, 93.63, 97.18,
    100.86
};

#endif /* DEFAULTPLIERCALIBDATA_H_ */
