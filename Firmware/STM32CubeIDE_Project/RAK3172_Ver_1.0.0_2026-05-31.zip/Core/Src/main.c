/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2026 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "dma.h"
#include "i2c.h"
#include "app_lorawan.h"
#include "tim.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "LoRaNodeConfig.h"
#include "BatterySensing.h"
#include "stdio.h"
#include "tca9534.h"
#include "GPIOSet.h"
#include "sel74hc151.h"
#include "tmux1204.h"
#include "ADCGeneric.h"
//#include "timInputCapture.h"
#include "sent.h"
#include "LMT01.h"
#include "pinzeFunctions.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
extern expander_t expanderI2C;
extern configurazioni_t config;

// variabili legate al SENT
extern uint8_t completato;
extern uint16_t numLetture;
extern uint16_t counts[MAXCOUNT];


/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
extern I2C_HandleTypeDef hi2c2;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void LowPower();

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_LoRaWAN_Init();
  MX_I2C2_Init();
  MX_TIM16_Init();
  MX_TIM17_Init();
  /* USER CODE BEGIN 2 */

	/*
	 * RICORDA DI DECOMMENTARE
	 *
	 *  MX_I2C2_Init();
	 *  MX_TIM16_Init();
	 *  MX_TIM17_Init();
	 */
	// deinizializzo l'I2C per consumare di meno
	//	HAL_I2C_DeInit(&hi2c2);

	accendiLed();

	// configuro l'INIT del nodo
	NodeConfigInit();

	// se necessario, guardiamo quantosono grandi gli spazi di memoria per le  varie strutture
	//PrintVariablesSize();


	/* ------ Lettura ALIMENTAZIONE PERIFERICHE ----------*/
	uint16_t battVoltage = 0;
	uint16_t internalBattery = 0;
	leggiBatterie(&battVoltage, &internalBattery, true);

	/* ------ DISATTIVAZIONE ALIMENTAZIONE PERIFERICHE ----------*/
	LowPower();


	/* --------- LETTURE PINZE -------------*/
	float media[MAX_NUM_PINZE], DEVstd[MAX_NUM_PINZE], temperatura[MAX_NUM_PINZE], diametro[MAX_NUM_PINZE];
	uint16_t VAdc[ANALOG_INPUT], Vref[ANALOG_INPUT];

//	APP_LOG( TS_OFF, VLEVEL_M, "######### ---- LETTURE DA SENT -----#########\n\r");
//
//	lettureSent(config.configurazionePinze, media, DEVstd, temperatura, true);
//	PrintPinzaStatistics(media, DEVstd, temperatura, NULL, MAX_NUM_PINZE);
//	/* --------- LETTURE ANALOGICHE -------------*/
//	APP_LOG( TS_OFF, VLEVEL_M, "######### ---- LETTURE INGRESSI ANALOGICI -----#########\n\r");
//
//	// effettua tutte e quattro le letture, in base alla struttura che gli si passa
//	readAllChannels(config.configurazioneAnalogSensor, VAdc, Vref);
//	PrintADCVoltages(VAdc, Vref);


	/******* tutte letture ****/
	inizializzaArrayAZero_float_UTILS(media, MAX_NUM_PINZE);
	inizializzaArrayAZero_float_UTILS(DEVstd, MAX_NUM_PINZE);
	inizializzaArrayAZero_float_UTILS(temperatura, MAX_NUM_PINZE);
	inizializzaArrayAZero_float_UTILS(diametro, MAX_NUM_PINZE);
	APP_LOG( TS_OFF, VLEVEL_M, "\n\r\n\r-----------PROVA FUNZIONI----------\n\r");
	tutteLetture(media, DEVstd, VAdc, Vref, temperatura, diametro);
	PrintADCVoltages(VAdc, Vref);
	PrintPinzaStatistics(media, DEVstd, temperatura, diametro, MAX_NUM_PINZE);

	LowPower();
	spegniLed();

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	while (1)
	{

    /* USER CODE END WHILE */
    MX_LoRaWAN_Process();

    /* USER CODE BEGIN 3 */
	}
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure LSE Drive Capability
  */
  HAL_PWR_EnableBkUpAccess();
  __HAL_RCC_LSEDRIVE_CONFIG(RCC_LSEDRIVE_LOW);

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSE|RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.LSEState = RCC_LSE_ON;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = RCC_MSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_11;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure the SYSCLKSource, HCLK, PCLK1 and PCLK2 clocks dividers
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK3|RCC_CLOCKTYPE_HCLK
                              |RCC_CLOCKTYPE_SYSCLK|RCC_CLOCKTYPE_PCLK1
                              |RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_MSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.AHBCLK3Divider = RCC_SYSCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void LowPower()
{
	/* ------ DISATTIVAZIONE ALIMENTAZIONE PERIFERICHE ----------*/
	APP_LOG( TS_OFF, VLEVEL_M, "-----------DISATTIVAZIONE PERIFERICHE----------\n\r");
	// GESTIONE INGRESSI ANALOGICI: alimentazione a connettore esterno
//	powerStages(POWER_STAGE_ANALOG_POWERIN, POWER_ON);
//	HAL_Delay(1000);
	powerStages(POWER_STAGE_ANALOG_POWERIN, POWER_OFF);
	// Spengo i mux ingresso analogico
	analog_mux_LowPower();

	// GESTIONE PINZE: expander I2C
//	powerStages(POWER_STAGE_PINZE_ON, POWER_ON);
//	HAL_Delay(1000);
	// disattivo i selettori degliingressi digitali delle pinze
	hc151_mux_LowPower();
//	hc151_mux_ExitLowPower();
//	hc151_select_input(SelCH0InputPinze);
//	hc151_select_input(SelCH1InputPinze);
//	hc151_select_input(SelCH2InputPinze);
//	hc151_select_input(SelCH7InputPinze);
//	hc151_mux_LowPower();
	powerStages(POWER_STAGE_PINZE_ON, POWER_OFF);
	// 5V alimentazione
//	powerStages(POWER_STAGE_BOOST_ON_PINZE, POWER_ON);
//	HAL_Delay(1000);
	powerStages(POWER_STAGE_BOOST_ON_PINZE, POWER_OFF);
	// disattivo l'I2C
	HAL_I2C_DeInit(&hi2c2);
	TIM16_DeInit();
	TIM17_DeInit();

	// GESTIONE SENSING BATTERIA: switch batteria
	powerStages(POWER_STAGE_VSTORAGE_READ_ACT, POWER_OFF);

}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1)
	{
	}
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
	/* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
