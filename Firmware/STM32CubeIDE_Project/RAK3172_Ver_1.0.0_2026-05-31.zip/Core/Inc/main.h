/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32wlxx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */


/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define RTC_PREDIV_A ((1<<(15-RTC_N_PREDIV_S))-1)
#define RTC_N_PREDIV_S 10
#define RTC_PREDIV_S ((1<<RTC_N_PREDIV_S)-1)
#define TempDigitalOutput_Pin GPIO_PIN_9
#define TempDigitalOutput_GPIO_Port GPIOB
#define BoostOnPinze_Pin GPIO_PIN_14
#define BoostOnPinze_GPIO_Port GPIOB
#define PinzeOn_Pin GPIO_PIN_10
#define PinzeOn_GPIO_Port GPIOA
#define SENTInput_Pin GPIO_PIN_8
#define SENTInput_GPIO_Port GPIOB
#define CTRLC_Pin GPIO_PIN_2
#define CTRLC_GPIO_Port GPIOC
#define VStorage_Pin GPIO_PIN_13
#define VStorage_GPIO_Port GPIOB
#define AnalogPowerIN_Pin GPIO_PIN_2
#define AnalogPowerIN_GPIO_Port GPIOB
#define AnSel1_Pin GPIO_PIN_9
#define AnSel1_GPIO_Port GPIOA
#define VStorageReadActivate_Pin GPIO_PIN_12
#define VStorageReadActivate_GPIO_Port GPIOB
#define AnalogIN_Pin GPIO_PIN_1
#define AnalogIN_GPIO_Port GPIOB
#define CTRLB_Pin GPIO_PIN_1
#define CTRLB_GPIO_Port GPIOC
#define CTRLA_Pin GPIO_PIN_0
#define CTRLA_GPIO_Port GPIOC
#define RTSn_Pin GPIO_PIN_6
#define RTSn_GPIO_Port GPIOA
#define RTSn_EXTI_IRQn EXTI9_5_IRQn
#define indicatore_Pin GPIO_PIN_11
#define indicatore_GPIO_Port GPIOB
#define BlueButton_Pin GPIO_PIN_7
#define BlueButton_GPIO_Port GPIOA
#define CTS_Pin GPIO_PIN_5
#define CTS_GPIO_Port GPIOA
#define AnSel0_Pin GPIO_PIN_8
#define AnSel0_GPIO_Port GPIOA

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
