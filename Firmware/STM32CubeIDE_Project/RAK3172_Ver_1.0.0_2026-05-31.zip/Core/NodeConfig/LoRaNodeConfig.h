/*
 * LoRaNodeConfig.h
 *
 *  Created on: 21 gen 2026
 *      Author: L
 */

#ifndef APPLICATION_USER_NODECONFIG_LORANODECONFIG_H_
#define APPLICATION_USER_NODECONFIG_LORANODECONFIG_H_

#include <stdint.h>
#include <stdbool.h>
#include "sys_app.h"
#include "LmHandler.h"
#include "cube_spline.h"

/*
 * INCLUDE dai sensori
 */
//#include "driver_ads1115.h"

#define UARTTIMEOUT 1000

#define SOGLIA_BATTERIA_TX (uint16_t)3650U /* mV */

#define MAX_VOLTAGE_THRESHOLD_BATTERY   ((uint16_t)3850U) /* mV */
#define MIN_VOLTAGE_THRESHOLD_BATTERY   SOGLIA_BATTERIA_TX /* mV */

#define FATTORE_MOLTIPLICATIVO_SAMPLING 3.0f


/*
 * ------------ STATUS NODO ------------
 */
typedef enum
{
    normal = 0,
	configurazione
} StatusNodo_t;
/*
 * ------------ STATUS PINZE ------------
 */

typedef enum
{
    PINZA_DISATTIVA = 0,
    PINZA_ATTIVA
} AttivazionePinza_t;

/*
 * ------------ DEFINE memoria ------------
 * indirizzo dell'inizio della sezione di eeprom in cui scrivere i dati
 */
#define MAX_STORED_DATA 0xFF									// 256 byte
#define OPTION_BYTES_START_ADDRESS 0x0803FFFF-MAX_STORED_DATA
#define OFFSET_CONFIG	8
#define OFFSET_ID		0

/*
 * ------------ DEFINE numero periferiche ------------
 */

#define ANALOG_INPUT 4
#define MAX_NUM_PINZE 8

//#define DIGITAL_INPUT 2

/*
 * ------------ CONFIGURAZIONE LoRa ------------
 */
typedef struct
{
    int8_t   DR;          // Data Rate (8 bit)
    uint32_t  DevAddr;     // Device Address (4 byte)
    uint8_t   AppEUI[8];   // Application EUI (8 byte)
    uint8_t   NwkSKey[16]; // Network Session Key (16 byte)
    uint8_t   AppSKey[16]; // Application Session Key (16 byte)
    int32_t   TXTime;      // Transmission Time (64 bit)
    bool      ADREnable;   // Adaptive Data Rate enable
} LoRaConfigABP_t;


/*
 * ------------ CONFIGURAZIONE sensori interni ------------
 */

typedef struct
{
    bool               	tempCompensationActive;
    uint8_t            	AverageNum;
    AttivazionePinza_t 	pinzaEnable;
    float				radiusPlier;
    float				lClamp;
    float				lambdaPlier;
    float				lambdaClamp;
} configurazionePinze_t;

//typedef enum
//{
//    SDI12 = 0x00,        /** SDI12 */
//    OTHER = 0xFF
//}
//SensorType_t;
//
//typedef struct
//{
//    SensorType_t SensorType;          // 1 byte
//    uint8_t      standardComunicazione; // 1 byte
//    bool         EnableSensore;        // 1 byte
//} configurazioneDigitalSensor_t;
//
typedef struct
{
    uint8_t preSample;       // delay prima della prima lettura (ms)
    uint8_t numSamples;      // numero di campioni da mediare
    bool    EnableSensore;   // abilita/disabilita il sensore
} configurazioneAnalogSensor_t;


typedef struct
{
	LoRaConfigABP_t LoRaConfig;
	configurazionePinze_t configurazionePinze[MAX_NUM_PINZE];
	configurazioneAnalogSensor_t configurazioneAnalogSensor[ANALOG_INPUT];
//	serve perchè la struttura risulti di dimensione kulipla di 8 byte, altrimenti non si riesce a scrivere su eeprom
	uint32_t restoreSizeMultEight;

} configurazioni_t;

typedef struct
{
	float pinzeRaw[MAX_NUM_PINZE];
	float temperatura[MAX_NUM_PINZE];
	float pinzeDiametro[MAX_NUM_PINZE];
	uint16_t analogLetture[ANALOG_INPUT];
} datiSensori_t;
/*
 * lista dei comandi chepossono arrivare da seriale
 */
typedef enum
{
    WhoAmI                        = 0x00,
    CMDGetSWVersion               = 0x01,
    CMDLeggiLoRaDati              = 0x02,
    CMDScriviLoRaDati             = 0x03,
    CMDLeggiVbatt                 = 0x04,
    CMDGetTime                    = 0x05,
    CMDSetTime                    = 0x06,
	CMDLeggiConfigPinze	          = 0x10,
    CMDScriviConfigPinze	      = 0x11,
	CMDLeggiConfigAnalogSensor    = 0x12,
	CMDScriviConfigAnalogSensor   = 0x13,
//    CMDLeggiVbatt_2               = 0x16,  // se realmente necessario
    CMDLeggiSensori	              = 0x14,
    } Command_t;



/* Lunghezze comandi (byte) */

#define CMDLeggiLoRaDati_LEN                 50
#define CMDScriviLoRaDati_LEN                50

#define CMDLeggiConfigPinze_LEN             20
#define CMDScriviConfigPinze_LEN            20

#define CMDLeggiConfigAnalogSensor_LEN      3
#define CMDScriviConfigAnalogSensor_LEN     3

#define CMDLeggiVbatt_LEN                    4


/*
 * Prototipi funzioni LoRa
 */
LmHandlerErrorStatus_t LoRaSTOP();

void LoRaSTART();


LmHandlerErrorStatus_t SetLoRaDatas();


LmHandlerErrorStatus_t GetLoRaDatas();

LmHandlerErrorStatus_t PrintLoRaDatas();

void CallbackSeriale(uint8_t *pdata, uint16_t size, uint8_t error);
void HandlerSeriale(Command_t comando);

/*
 * prototipo funzione di init
 */
uint8_t NodeConfigInit();


/*
 * funzioni del tempo
 */

void SetTimeRTC(SysTime_t time);
uint32_t GetTimeRTCEpoch();
void GetTimeRTC();


/*
 * gestione del tempo di acquisizione in funzione della carica di batteria
 */
uint32_t interpolate_sampling_time(uint16_t voltage, uint32_t sampling_time_s);

#endif /* APPLICATION_USER_NODECONFIG_LORANODECONFIG_H_ */
