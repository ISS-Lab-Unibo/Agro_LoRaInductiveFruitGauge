/*
 * LoRaNodeConfig.c
 *
 *  Created on: 22 gen 2026
 *      Author: L
 */
//#include "LoRaMacTypes.h"
//#include "secure-element.h"
#include "LoRaNodeConfig.h"
#include "stm32wlxx_hal.h"
#include "lora_app.h"
#include "sys_app.h"
#include "flash_if.h"
#include "string.h"
#include "stm32_seq.h"
#include "usart.h"
#include "app_version.h"
#include "stm32wlxx_hal_uart.h"
#include "BatterySensing.h"
#include "usart_if.h"
#include "pinzeFunctions.h"
#include "defaultPlierCalibData.h"


#define HEX8(X)   X[0], X[1], X[2], X[3], X[4], X[5], X[6], X[7]
#define HEX16(X)  HEX8(X), X[8], X[9], X[10], X[11], X[12], X[13], X[14], X[15]

#define WHOAMI 	0xAB
#define ACK 	0xAF

uint8_t task[4];

extern RTC_HandleTypeDef hrtc;
//extern UART_HandleTypeDef hlpuart1;


// struttura dei coefficienti di calibrazione delle pinze
S calibCoefficients[MAX_NUM_PINZE];

/*
 * Struttura dati di configurazione
 */
configurazioni_t config;

uint8_t configSize = 0;

StatusNodo_t statoNodo = normal;

/*
 * FUNZIONI DI SERVIZIO
 */
LmHandlerErrorStatus_t changeLoRaDatas();

void erroreFlash()
{
//	APP_LOG(TS_OFF, VLEVEL_M, "----------- ERRORE FLASH -----------\n\r\n\r");
	HAL_Delay(10);
}

void erroreChangeLoRadatas()
{
//	APP_LOG(TS_OFF, VLEVEL_M, "----------- ERRORE FLASH -----------\n\r\n\r");
	HAL_Delay(10);
}

/*
 * ----------------------- INIZIALIZZAZIONE DELLE MEMORIE -----------------------
 */

uint8_t NodeConfigInit()
{
	APP_LOG(TS_OFF, VLEVEL_M, "\n\r----------- CALIBRAZIONE PARAMETRI PINZE -----------\n\r\n\r");
	for (uint8_t i = 0; i<MAX_NUM_PINZE;i++)
	{
		// carico i coefficienti di calibrazione e calcolo i parametri della SPLINE
		uint8_t lunghezza = sizeof(X)/4;
		for (uint8_t j =0; j<lunghezza; j++)
		{
			calibCoefficients[i].x = X;
			calibCoefficients[i].y = Y;
			nat_cubic_spline(lunghezza, &calibCoefficients[i]);
		}
	}

	APP_LOG(TS_OFF, VLEVEL_M, "\n\r----------- CARICAMENTO PARAMETRI LoRa -----------\n\r\n\r");
	configSize = sizeof(config);

	uint32_t addFlash = OPTION_BYTES_START_ADDRESS + OFFSET_CONFIG;

	char ID[8];
	char IDRef[8] = "DATA_MEM";

//
//	APP_LOG(TS_OFF, VLEVEL_M, "Dimensione struttura dati configurazione: %d B\n\r", configSize);
//	if (IS_ADDR_ALIGNED_64BITS(configSize) == 0)
//	{
//		APP_LOG(TS_OFF, VLEVEL_M, "Dimensione struttura dati non idonea alla memorizzazione (no multiplo di 8B)\n\r\n\r");
//	}
//
//	uint8_t sizee = sizeof(ID);
//	if (IS_ADDR_ALIGNED_64BITS(sizeof(ID)) == 0)
//	{
//		APP_LOG(TS_OFF, VLEVEL_M, "Dimensione ID non idonea alla memorizzazione (no multiplo di 8B)\n\r\n\r");
//	}
//
//
//	if (IS_ADDR_ALIGNED_64BITS(OPTION_BYTES_START_ADDRESS) == 0)
//	{
//		APP_LOG(TS_OFF, VLEVEL_M, "Indirizzo in cui scrivere la struttura dati nella flash non idonea alla memorizzazione (no multiplo di 8B)\n\r\n\r");
//	}
//
//	if (IS_ADDR_ALIGNED_64BITS(addFlash) == 0)
//	{
//		APP_LOG(TS_OFF, VLEVEL_M, "Indirizzo di inizio scrittura nella flash non idonea alla memorizzazione (no multiplo di 8B)\n\r\n\r");
//	}

	// leggo i dati attuali da memoria, controllando se prima c'è la sequenza di controllo che identifica la presenza di una configurazione in EEPROM
	if (FLASH_IF_OK != FLASH_IF_Read(&ID, (void*)OPTION_BYTES_START_ADDRESS, sizeof(ID)))
			{
				erroreFlash();
				return 1;
			}

	// leggo in EEPROM se ho una stringa identificativa "DATA_MEM"
	// se le stringhe sono uguali, abbiamo i dati di configurazione già dalla memoria
	// e quindi li carichiamo
	if (memcmp(&ID, &IDRef, sizeof(ID)) == 0)
	{
		if (FLASH_IF_OK != FLASH_IF_Read(&config, (uint32_t*)addFlash, configSize))
		{
			erroreFlash();
			APP_LOG(TS_OFF, VLEVEL_M, "Errore in lettura parametri da EEPROM \n\r\n\r");
			return 1;
		}
		LmHandlerErrorStatus_t statoHandler = SetLoRaDatas();
		if (statoHandler != LORAMAC_HANDLER_SUCCESS)
			{
			APP_LOG(TS_OFF, VLEVEL_M, "Errore in impostazione dati LoRa da EEPROM \n\r\n\r");
			}
		APP_LOG(TS_OFF, VLEVEL_M, "Caricati parametri da EEPROM\n\r\n\r");
	}
	else
	{
		APP_LOG(TS_OFF, VLEVEL_M, "Caricamento dati di configurazione Hard coded in codice\n\r\n\r");
		for (uint8_t i = 0; i<MAX_NUM_PINZE; i++)
		{
			config.configurazionePinze[i].AverageNum = 1;
			config.configurazionePinze[i].pinzaEnable = PINZA_DISATTIVA;
			config.configurazionePinze[i].tempCompensationActive = false;
			config.configurazionePinze[i].radiusPlier = 120;
			config.configurazionePinze[i].lClamp = 4;
			config.configurazionePinze[i].lambdaPlier = 0;
			config.configurazionePinze[i].lambdaClamp = 0;

		}
		for (uint8_t i = 0; i<ANALOG_INPUT; i++)
		{
			config.configurazioneAnalogSensor[i].preSample = 1;
			config.configurazioneAnalogSensor[i].numSamples = 1;
			config.configurazioneAnalogSensor[i].EnableSensore = false;
		}
		// si caricano i dati LoRa
		if (GetLoRaDatas() != LORAMAC_HANDLER_SUCCESS)
		{
			APP_LOG(TS_OFF, VLEVEL_M, "Errore in impostazione dati di default LoRa \n\r\n\r");
			return 1;
		}
		APP_LOG(TS_OFF, VLEVEL_M, "Caricati dati di default Hard coded\n\r\n\r");
	}


	PrintLoRaDatas();

	//	if (FLASH_IF_OK != FLASH_IF_Write((uint32_t*)addFlash, &ID, 8))
	//		erroreFlash();
	return 0;
}



/*
 * ----------------------- CALLBACK LoRa -----------------------
 */

/*
 * Questo ocmando permette di fermare la macchina a stati Lora
 * per farla ripartire usa la LmHandlerJoin( ACTIVATION_TYPE_ABP, true );
 */
LmHandlerErrorStatus_t LoRaSTOP()
{
	// fermo i vari task
	task[0] = UTIL_SEQ_IsPauseTask(1 << CFG_SEQ_Task_LmHandlerProcess);
	task[1] = UTIL_SEQ_IsPauseTask(1 << CFG_SEQ_Task_LoRaSendOnTxTimerOrButtonEvent);
	task[2] = UTIL_SEQ_IsPauseTask(1 << CFG_SEQ_Task_LoRaStoreContextEvent);
	task[3] = UTIL_SEQ_IsPauseTask(1 << CFG_SEQ_Task_LoRaStopJoinEvent);
	HAL_Delay(100);
	if (LORAMAC_HANDLER_SUCCESS != LmHandlerStop())
	{
		APP_LOG(TS_OFF, VLEVEL_M, "LmHandler Stop on going ...\r\n");
		return LORAMAC_HANDLER_BUSY_ERROR;
	}
	else
	{
		//		HAL_Delay(10);
		APP_LOG(TS_OFF, VLEVEL_M, "LmHandler Stop eseguito correttamente\r\n");
		if(task[0] == 0)
			UTIL_SEQ_PauseTask(1 << CFG_SEQ_Task_LmHandlerProcess);
		if(task[1] == 0)
			UTIL_SEQ_PauseTask(1 << CFG_SEQ_Task_LoRaSendOnTxTimerOrButtonEvent);
		if(task[2] == 0)
			UTIL_SEQ_PauseTask(1 << CFG_SEQ_Task_LoRaStoreContextEvent);
		if(task[3] == 0)
			UTIL_SEQ_PauseTask(1 << CFG_SEQ_Task_LoRaStopJoinEvent);
		return LORAMAC_HANDLER_SUCCESS;
	}
}

void LoRaSTART()
{
	// fermo i vari task
	task[0] = UTIL_SEQ_IsPauseTask(1 << CFG_SEQ_Task_LmHandlerProcess);
	task[1] = UTIL_SEQ_IsPauseTask(1 << CFG_SEQ_Task_LoRaSendOnTxTimerOrButtonEvent);
	task[2] = UTIL_SEQ_IsPauseTask(1 << CFG_SEQ_Task_LoRaStoreContextEvent);
	task[3] = UTIL_SEQ_IsPauseTask(1 << CFG_SEQ_Task_LoRaStopJoinEvent);
	LmHandlerJoin(ACTIVATION_TYPE_ABP, true);
	APP_LOG(TS_OFF, VLEVEL_M, "-----------LmHandler in riattivazione-----------\r\n");
	HAL_Delay(10);
	if(task[0] == 1)
		UTIL_SEQ_ResumeTask(1 << CFG_SEQ_Task_LmHandlerProcess);
	if(task[1] == 1)
		UTIL_SEQ_ResumeTask(1 << CFG_SEQ_Task_LoRaSendOnTxTimerOrButtonEvent);
	if(task[2] == 1)
		UTIL_SEQ_ResumeTask(1 << CFG_SEQ_Task_LoRaStoreContextEvent);
	if(task[3] == 1)
		UTIL_SEQ_ResumeTask(1 << CFG_SEQ_Task_LoRaStopJoinEvent);
	APP_LOG(TS_OFF, VLEVEL_M, "-----------Task riattivati--------\r\n\r\n");
	HAL_Delay(100);
}



/*
 * salva i valori di configurazione Lora nella struttura LoRaConfig
 */
LmHandlerErrorStatus_t GetLoRaDatas()
{
	LmHandlerErrorStatus_t stato = LORAMAC_HANDLER_SUCCESS;
	stato += LmHandlerGetTxDatarate(&config.LoRaConfig.DR);
	stato += LmHandlerGetDevAddr(&config.LoRaConfig.DevAddr);
	stato += LmHandlerGetAppEUI(config.LoRaConfig.AppEUI);
	config.LoRaConfig.TXTime = APP_TX_DUTYCYCLE;
	//	LoRaConfig.TXTime = LmHandlerGetDutyCycleWaitTime();
	stato += LmHandlerGetAdrEnable(&config.LoRaConfig.ADREnable);
	stato += LmHandlerGetKey(NWK_S_KEY, config.LoRaConfig.NwkSKey);
	stato += LmHandlerGetKey(APP_S_KEY, config.LoRaConfig.AppSKey);
	return stato;
}

/*
 * si presuppone che i dati di LoRaConfig siano stati aggiornati esternamente.
 * Poi, si richiama questa funzione che fa ripartire anche tutto il sistema LoRa
 */
LmHandlerErrorStatus_t SetLoRaDatas()
{
	LmHandlerErrorStatus_t stato = LORAMAC_HANDLER_SUCCESS;
	stato = LoRaSTOP();

	stato += changeLoRaDatas();

	/*
	 * il chip butta fuori +22dBm, il limite europeo dovrebbe essere +14 dBm EIRP, gli 8 dB di differenza si ottengono settando a 4 il valore di potenza
	 * Guarda il file rp2-1-0-3-lorawan-regional-parameters.pdf, RP002-1.0.3 LoRaWAN® Regional Parameters
	 * DA CAMBIARE SE SI USA IL CHIP CON USCITA Low POWER!!!!, lì, la massima potenza di uscita è +15 dBm
	 */
	int8_t power;
	stato += LmHandlerGetTxPower(&power);
	power = 4;
	stato += LmHandlerSetTxPower(power);
	APP_LOG(TS_OFF, VLEVEL_M, "potenza: %d \n\r\n\r", power);

	LoRaSTART();

	return stato;
}


/*
 * Per settare i vari parametri LoRa DALLA STRUTTURA "config" allo stack che gira nel microcontrollore
 */
LmHandlerErrorStatus_t changeLoRaDatas()
{
	LmHandlerErrorStatus_t stato = LORAMAC_HANDLER_SUCCESS;
	stato += LmHandlerSetDevAddr(config.LoRaConfig.DevAddr);
	//	HAL_Delay(10);
	stato += LmHandlerSetTxDatarate(config.LoRaConfig.DR);
	//	HAL_Delay(10);
	stato += LmHandlerSetAppEUI(config.LoRaConfig.AppEUI);
	//	HAL_Delay(10);
	//	LoRaConfig.TXTime = LmHandlerGetDutyCycleWaitTime();
	stato += LmHandlerSetAdrEnable(config.LoRaConfig.ADREnable);
	//	HAL_Delay(10);
	stato += LmHandlerSetKey(NWK_S_KEY, config.LoRaConfig.NwkSKey);
	//	HAL_Delay(10);
	stato += LmHandlerSetKey(APP_S_KEY, config.LoRaConfig.AppSKey);
	//	HAL_Delay(10);

	LmHandlerJoin( ACTIVATION_TYPE_ABP, true );
	cambiaTxPeriodicity(config.LoRaConfig.TXTime);
	return stato;
}

/*
 * stampiamo i dati che stanno girando effettivamente nello stack LoRa
 */
LmHandlerErrorStatus_t PrintLoRaDatas()
{

	APP_LOG( TS_OFF, VLEVEL_M,"\n\r\n\r ------------ IMPOSTAZIONI LoRa ------------ \n\r\n\r");
	LoRaConfigABP_t LoRaConfig;
	LmHandlerErrorStatus_t stato = LORAMAC_HANDLER_SUCCESS;
	stato += LmHandlerGetKey(NWK_S_KEY, LoRaConfig.NwkSKey);
	stato += LmHandlerGetKey(APP_S_KEY, LoRaConfig.AppSKey);

	APP_LOG( TS_OFF, VLEVEL_M,"###### NetSKey %02X:%02X:%02X:%02X:%02X:%02X:%02X:%02X:%02X:%02X:%02X:%02X:%02X:%02X:%02X:%02X\r\n", HEX16( LoRaConfig.NwkSKey ) );
	APP_LOG( TS_OFF, VLEVEL_M,"###### AppSKey %02X:%02X:%02X:%02X:%02X:%02X:%02X:%02X:%02X:%02X:%02X:%02X:%02X:%02X:%02X:%02X\r\n", HEX16( LoRaConfig.AppSKey ) );


	stato += LmHandlerGetTxDatarate(&LoRaConfig.DR);
	stato += LmHandlerGetDevAddr(&LoRaConfig.DevAddr);
	stato += LmHandlerGetAppEUI(LoRaConfig.AppEUI);

	APP_LOG( TS_OFF, VLEVEL_M, "###### DevAddr:     %02X:%02X:%02X:%02X\r\n",( unsigned )( ( unsigned char * )( &LoRaConfig.DevAddr ) )[3],( unsigned )( ( unsigned char * )( &LoRaConfig.DevAddr ) )[2],( unsigned )( ( unsigned char * )( &LoRaConfig.DevAddr ) )[1],( unsigned )( ( unsigned char * )( &LoRaConfig.DevAddr ) )[0] );
	APP_LOG( TS_OFF, VLEVEL_M, "###### AppEUI:      %02X:%02X:%02X:%02X:%02X:%02X:%02X:%02X\r\n", HEX8( LoRaConfig.AppEUI ) );

	// tipo dato LmHandlerAdrStates_t
	if (LoRaConfig.ADREnable == LORAMAC_HANDLER_ADR_OFF)
		APP_LOG( TS_OFF, VLEVEL_M, "###### ADR OFF\n\r")
		else
			APP_LOG( TS_OFF, VLEVEL_M, "###### ADR ON\n\r");
	uint32_t periodicity =leggiTxPeriodicity();
	APP_LOG( TS_OFF, VLEVEL_M, "###### TxTime:     %d\r\n",periodicity);
	APP_LOG( TS_OFF, VLEVEL_M, "###### DR%d", LoRaConfig.DR);
	APP_LOG( TS_OFF, VLEVEL_M,"\n\r\n\r ----------- FINE STAMPA PARAMETRI LoRa ------------- \n\r\n\r");

	return stato;
}


/*
 * ----------------------- CALLBACK COMANDO ARRIVATO DA SERIALE -----------------------
 */

void CallbackSeriale(uint8_t *pdata, uint16_t size, uint8_t error)
{
	/*
	 * qui dentro, e nelle sue funzioni sottoposte, non usare l'APP LOG!!!
	 * Altrimenti non trasmette null aperchè l'interfaccia è sempre busy
	 */
	uint8_t receivedCommand;
	receivedCommand = *pdata;
//	APP_LOG( TS_OFF, VLEVEL_M, "###### Ricevuto valore da seriale:     %c\r\n",receivedCommand);
	// il delay serve per dare il tempo di stampare il buffer a schermo
	HAL_Delay(10);
	HandlerSeriale((Command_t)receivedCommand);
}

/*
 * ----------------------- COMANDI ARRIVATI DA SERIALE e loro gestione -----------------------
 */


void HandlerSeriale(Command_t comando)
{
    uint8_t Ack = ACK;
    bool updateMem = false;
    uint8_t size;
    switch (comando)
    {
        case WhoAmI:                // 0x00
            // Invia identificativo dispositivo
//       		HAL_StatusTypeDef stato = HAL_OK;
        	uint8_t whoami = WHOAMI;
        	HAL_Delay(50);
       		vcom_Trace(&whoami, 1);
            break;

        case CMDGetSWVersion:       // 0x01
            // Invia versione firmware
        	uint32_t version = APP_VERSION;
        	HAL_Delay(10);
        	vcom_Trace((uint8_t*)&version, 4);
        	break;

        case CMDLeggiLoRaDati:      // 0x02
        	size = sizeof(config.LoRaConfig);
        	HAL_Delay(10);
        	vcom_Trace((uint8_t*)&config.LoRaConfig, size);
            break;

        case CMDScriviLoRaDati:     // 0x03
            // Scrittura configurazione LoRa
            HAL_Delay(10);
        	vcom_Trace((uint8_t*)&Ack, 1);
        	// ricevo i valori da spacchettare
        	vcom_ReceiveTrace((uint8_t*)&config.LoRaConfig, sizeof(config.LoRaConfig));
//			controlla i dati
        	HAL_Delay(20);
//        	// mando l'ACK
//        	vcom_Trace((uint8_t*)&Ack, 1);
//        	HAL_Delay(50);
            updateMem = true;
            break;

        case CMDLeggiVbatt:         // 0x04
        {
            uint16_t internal, external;
            uint32_t voltages;
            readBatteryVoltage(&external, &internal);
            voltages = (internal  << 16) | (external << 0);
        	HAL_Delay(10);
            vcom_Trace((uint8_t*)&voltages, 4);
            break;
        }

        case CMDGetTime:            // 0x05
            // Invia timestamp corrente
        	uint32_t epoch = 0;
        	epoch = GetTimeRTCEpoch();
        	vcom_Trace((uint8_t*)&epoch, 4);
            break;

        case CMDSetTime:            // 0x06
            // Imposta timestamp
            updateMem = false;
            HAL_Delay(10);
        	vcom_Trace((uint8_t*)&Ack, 1);
//        	HAL_UART_Receive(&hlpuart1, p_data, size, 1000);
        	uint32_t epochRX = 0;
        	vcom_ReceiveTrace((uint8_t*)&epochRX, 4);
        	SysTime_t reWriteTime;
        	reWriteTime.Seconds = epochRX;
        	reWriteTime.SubSeconds = 0;
        	SetTimeRTC(reWriteTime);
        	HAL_Delay(10);
        	// mando l'ACK
        	vcom_Trace((uint8_t*)&Ack, 1);
        	HAL_Delay(10);



            break;

        case CMDLeggiConfigPinze:      // 0x10
        	size = sizeof(configurazionePinze_t)*MAX_NUM_PINZE;
        	HAL_Delay(10);
        	vcom_Trace((uint8_t*)&config.configurazionePinze, size);
            break;

        case CMDScriviConfigPinze:     // 0x11
            HAL_Delay(10);
        	vcom_Trace((uint8_t*)&Ack, 1);
        	// ricevo i valori da spacchettare
        	vcom_ReceiveTrace((uint8_t*)&config.configurazionePinze, sizeof(configurazionePinze_t)*MAX_NUM_PINZE);
        	HAL_Delay(20);
            updateMem = true;
            break;

        case CMDLeggiConfigAnalogSensor:   // 0x12
        	size = sizeof(configurazioneAnalogSensor_t)*ANALOG_INPUT;
        	HAL_Delay(10);
        	vcom_Trace((uint8_t*)&config.configurazioneAnalogSensor, size);
            break;

        case CMDScriviConfigAnalogSensor:  // 0x13
            HAL_Delay(10);
        	vcom_Trace((uint8_t*)&Ack, 1);
        	// ricevo i valori da spacchettare
        	vcom_ReceiveTrace((uint8_t*)&config.configurazioneAnalogSensor, sizeof(configurazioneAnalogSensor_t)*ANALOG_INPUT);
        	HAL_Delay(20);
            updateMem = true;
            break;

        case CMDLeggiSensori:   // 0x14
//        	LoRaSTART();
        	HAL_Delay(10);
        	datiSensori_t datiLetti;
        	float dummy[MAX_NUM_PINZE];
        	uint16_t dummy16[MAX_NUM_PINZE];
        	tutteLetture(datiLetti.pinzeRaw, dummy, datiLetti.analogLetture, dummy16, datiLetti.temperatura, datiLetti.pinzeDiametro);
        	uint8_t lunghezzaDati = sizeof(datiLetti);
        	vcom_Trace((uint8_t*)&datiLetti, lunghezzaDati);
            break;


        default:
            APP_LOG(TS_OFF, VLEVEL_M, "COMANDO NON RICONOSCIUTO\r\n");
            break;
    }

    if (updateMem == true)
    {
        updateMem = false;
        char ID[8] = "DATA_MEM";
//        strcpy(ID, "DATA_MEM");
        uint32_t addFlash = OPTION_BYTES_START_ADDRESS + OFFSET_CONFIG;
        FLASH_IF_StatusTypedef stato = FLASH_IF_Write((void*)OPTION_BYTES_START_ADDRESS, ID, sizeof(ID));
        if (FLASH_IF_OK != stato)
        {
            erroreFlash();
        }
//        FLASH_IF_StatusTypedef stato = FLASH_IF_Write(&config, (uint32_t*)addFlash, sizeof(config));
        stato = FLASH_IF_Write((void*)addFlash, &config, sizeof(config));
        if (FLASH_IF_OK != stato)
        {
            erroreFlash();
        }
        // invio l'ACK
    	HAL_Delay(10);
    	vcom_Trace((uint8_t*)&Ack, 1);
    	HAL_Delay(10);
//    	vcom_Trace((uint8_t*)&size, 4);
		LmHandlerErrorStatus_t statoHandler = changeLoRaDatas();
		if (statoHandler != LORAMAC_HANDLER_SUCCESS)
			{
//			APP_LOG(TS_OFF, VLEVEL_M, "Errore in impostazione dati LoRa da EEPROM \n\r\n\r");
			erroreChangeLoRadatas();
			}
    }
}


/*
 * funzione per settare il tempo nel nodo
 */

// qui entra epoch e setto l'orario
void SetTimeRTC(SysTime_t time)
{
//	// imposto il tempo dell'RTC
//	HAL_StatusTypeDef statoRTC = HAL_OK;
//	RTC_TimeTypeDef time;
//	time.Hours = 10;
//	time.Minutes = 10;
//	time.Seconds = 0;
//	statoRTC += HAL_RTC_SetTime(&hrtc, &time, RTC_BINARY_ONLY);
//	RTC_DateTypeDef date;
//	date.Month = RTC_MONTH_JANUARY;
//	date.Year = 26;
//	date.WeekDay = RTC_WEEKDAY_MONDAY;
//	date.Date = 1;
//	statoRTC += HAL_RTC_SetDate(&hrtc, &date, RTC_FORMAT_BIN);

	SysTimeSet(time);
//	SysTimeMkTime();
//	if (statoRTC != HAL_OK)
//		APP_LOG( TS_OFF, VLEVEL_M, "-----------ERRORE scrittura RTC ----------\n\r");
}


// leggo l'epoch
uint32_t GetTimeRTCEpoch()
{
	SysTime_t time;
	time = SysTimeGet();
	return time.Seconds;
}

// leggo il valore già scisso in giorno ed ora ecc
void GetTimeRTC(struct tm *tempo)
{
	uint32_t time = GetTimeRTCEpoch();
	SysTimeLocalTime(time, tempo);
}


uint32_t interpolate_sampling_time(uint16_t voltage, uint32_t sampling_time_s)
{
    float multiplier;

    /* Saturazione ai limiti */
    if (voltage >= MAX_VOLTAGE_THRESHOLD_BATTERY)
    {
        return sampling_time_s;
    }

    if (voltage <= MIN_VOLTAGE_THRESHOLD_BATTERY)
    {
        return (uint32_t )(sampling_time_s * FATTORE_MOLTIPLICATIVO_SAMPLING);
    }

    /* Interpolazione lineare */
    float normalized = (float)((MAX_VOLTAGE_THRESHOLD_BATTERY - voltage)) / ((float)(MAX_VOLTAGE_THRESHOLD_BATTERY - MIN_VOLTAGE_THRESHOLD_BATTERY));

    /*
     * normalizzazione:
     * 0 -> tensione massima
     * 1 -> tensione minima
     */

    multiplier = 1.0f + normalized * (FATTORE_MOLTIPLICATIVO_SAMPLING - 1.0f);

    return (uint32_t)(sampling_time_s * multiplier);
}


/*
 * _______________________COME USARE LE FUNZIONI_______________________
 *
 */

/*
 * TEMPO
 */

//// setto il tempo
//SysTime_t time;
//time.Seconds = 1770826667;	//11_02_2026
//SetTimeRTC(time);
//
//// leggo il tempo
//struct tm tempo;
//GetTimeRTC(&tempo);
//APP_LOG( TS_OFF, VLEVEL_M, "tempo %d\n\r", tempo.tm_sec);
