/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file    lora_app.c
 * @author  MCD Application Team
 * @brief   Application of the LRWAN Middleware
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2026 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "platform.h"
#include "sys_app.h"
#include "lora_app.h"
#include "stm32_seq.h"
#include "stm32_timer.h"
#include "utilities_def.h"
#include "app_version.h"
#include "lorawan_version.h"
#include "subghz_phy_version.h"
#include "lora_info.h"
#include "LmHandler.h"
#include "adc_if.h"
#include "CayenneLpp.h"
#include "sys_sensors.h"
#include "flash_if.h"

/* USER CODE BEGIN Includes */
#include "main.h"
#include "stm32_lpm.h"
#include "GPIOSet.h"
#include "pinzeFunctions.h"


/* USER CODE END Includes */

/* External variables ---------------------------------------------------------*/
/* USER CODE BEGIN EV */
extern StatusNodo_t statoNodo;
extern UART_HandleTypeDef hlpuart1;
/* USER CODE END EV */

/* Private typedef -----------------------------------------------------------*/
/**
 * @brief LoRa State Machine states
 */
typedef enum TxEventType_e
{
	/**
	 * @brief Appdata Transmission issue based on timer every TxDutyCycleTime
	 */
	TX_ON_TIMER,
	/**
	 * @brief Appdata Transmission external event plugged on OnSendEvent( )
	 */
	TX_ON_EVENT
	/* USER CODE BEGIN TxEventType_t */

	/* USER CODE END TxEventType_t */
} TxEventType_t;

/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/**
 * LEDs period value of the timer in ms
 */
#define LED_PERIOD_TIME 500

/**
 * Join switch period value of the timer in ms
 */
#define JOIN_TIME 2000

/*---------------------------------------------------------------------------*/
/*                             LoRaWAN NVM configuration                     */
/*---------------------------------------------------------------------------*/
/**
 * @brief LoRaWAN NVM Flash address
 * @note last 2 sector of a 128kBytes device
 */
#define LORAWAN_NVM_BASE_ADDRESS                    ((void *)0x0803F000UL)

/* USER CODE BEGIN PD */

static const char *slotStrings[] = { "1", "2", "C", "C_MC", "P", "P_MC" };
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private function prototypes -----------------------------------------------*/
/**
 * @brief  LoRa End Node send request
 */
static void SendTxData(void);

/**
 * @brief  TX timer callback function
 * @param  context ptr of timer context
 */
static void OnTxTimerEvent(void *context);

/**
 * @brief  join event callback function
 * @param  joinParams status of join
 */
static void OnJoinRequest(LmHandlerJoinParams_t *joinParams);

/**
 * @brief callback when LoRaWAN application has sent a frame
 * @brief  tx event callback function
 * @param  params status of last Tx
 */
static void OnTxData(LmHandlerTxParams_t *params);

/**
 * @brief callback when LoRaWAN application has received a frame
 * @param appData data received in the last Rx
 * @param params status of last Rx
 */
static void OnRxData(LmHandlerAppData_t *appData, LmHandlerRxParams_t *params);

/**
 * @brief callback when LoRaWAN Beacon status is updated
 * @param params status of Last Beacon
 */
static void OnBeaconStatusChange(LmHandlerBeaconParams_t *params);

/**
 * @brief callback when system time has been updated
 */
static void OnSysTimeUpdate(void);

/**
 * @brief callback when LoRaWAN application Class is changed
 * @param deviceClass new class
 */
static void OnClassChange(DeviceClass_t deviceClass);

/**
 * @brief  LoRa store context in Non Volatile Memory
 */
static void StoreContext(void);

/**
 * @brief  stop current LoRa execution to switch into non default Activation mode
 */
static void StopJoin(void);

/**
 * @brief  Join switch timer callback function
 * @param  context ptr of Join switch context
 */
static void OnStopJoinTimerEvent(void *context);

/**
 * @brief  Notifies the upper layer that the NVM context has changed
 * @param  state Indicates if we are storing (true) or restoring (false) the NVM context
 */
static void OnNvmDataChange(LmHandlerNvmContextStates_t state);

/**
 * @brief  Store the NVM Data context to the Flash
 * @param  nvm ptr on nvm structure
 * @param  nvm_size number of data bytes which were stored
 */
static void OnStoreContextRequest(void *nvm, uint32_t nvm_size);

/**
 * @brief  Restore the NVM Data context from the Flash
 * @param  nvm ptr on nvm structure
 * @param  nvm_size number of data bytes which were restored
 */
static void OnRestoreContextRequest(void *nvm, uint32_t nvm_size);

/**
 * Will be called each time a Radio IRQ is handled by the MAC layer
 *
 */
static void OnMacProcessNotify(void);

/**
 * @brief Change the periodicity of the uplink frames
 * @param periodicity uplink frames period in ms
 * @note Compliance test protocol callbacks
 */
static void OnTxPeriodicityChanged(uint32_t periodicity);

/**
 * @brief Change the confirmation control of the uplink frames
 * @param isTxConfirmed Indicates if the uplink requires an acknowledgement
 * @note Compliance test protocol callbacks
 */
static void OnTxFrameCtrlChanged(LmHandlerMsgTypes_t isTxConfirmed);

/**
 * @brief Change the periodicity of the ping slot frames
 * @param pingSlotPeriodicity ping slot frames period in ms
 * @note Compliance test protocol callbacks
 */
static void OnPingSlotPeriodicityChanged(uint8_t pingSlotPeriodicity);

/**
 * @brief Will be called to reset the system
 * @note Compliance test protocol callbacks
 */
static void OnSystemReset(void);

/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private variables ---------------------------------------------------------*/
/**
 * @brief LoRaWAN default activation type
 */
static ActivationType_t ActivationType = LORAWAN_DEFAULT_ACTIVATION_TYPE;

/**
 * @brief LoRaWAN force rejoin even if the NVM context is restored
 */
static bool ForceRejoin = LORAWAN_FORCE_REJOIN_AT_BOOT;

/**
 * @brief LoRaWAN handler Callbacks
 */
static LmHandlerCallbacks_t LmHandlerCallbacks =
{
		.GetBatteryLevel =              GetBatteryLevel,
		.GetTemperature =               GetTemperatureLevel,
		.GetUniqueId =                  GetUniqueId,
		.GetDevAddr =                   GetDevAddr,
		.OnRestoreContextRequest =      OnRestoreContextRequest,
		.OnStoreContextRequest =        OnStoreContextRequest,
		.OnMacProcess =                 OnMacProcessNotify,
		.OnNvmDataChange =              OnNvmDataChange,
		.OnJoinRequest =                OnJoinRequest,
		.OnTxData =                     OnTxData,
		.OnRxData =                     OnRxData,
		.OnBeaconStatusChange =         OnBeaconStatusChange,
		.OnSysTimeUpdate =              OnSysTimeUpdate,
		.OnClassChange =                OnClassChange,
		.OnTxPeriodicityChanged =       OnTxPeriodicityChanged,
		.OnTxFrameCtrlChanged =         OnTxFrameCtrlChanged,
		.OnPingSlotPeriodicityChanged = OnPingSlotPeriodicityChanged,
		.OnSystemReset =                OnSystemReset,
};

/**
 * @brief LoRaWAN handler parameters
 */
static LmHandlerParams_t LmHandlerParams =
{
		.ActiveRegion =             ACTIVE_REGION,
		.DefaultClass =             LORAWAN_DEFAULT_CLASS,
		.AdrEnable =                LORAWAN_ADR_STATE,
		.IsTxConfirmed =            LORAWAN_DEFAULT_CONFIRMED_MSG_STATE,
		.TxDatarate =               LORAWAN_DEFAULT_DATA_RATE,
		.TxPower =                  LORAWAN_DEFAULT_TX_POWER,
		.PingSlotPeriodicity =      LORAWAN_DEFAULT_PING_SLOT_PERIODICITY,
		.RxBCTimeout =              LORAWAN_DEFAULT_CLASS_B_C_RESP_TIMEOUT
};

/**
 * @brief Type of Event to generate application Tx
 */
static TxEventType_t EventType = TX_ON_TIMER;

/**
 * @brief Timer to handle the application Tx
 */
static UTIL_TIMER_Object_t TxTimer;

/**
 * @brief Tx Timer period
 */
static UTIL_TIMER_Time_t TxPeriodicity = APP_TX_DUTYCYCLE;

/**
 * @brief Join Timer period
 */
static UTIL_TIMER_Object_t StopJoinTimer;

/* USER CODE BEGIN PV */
/**
 * @brief User application buffer
 */
static uint8_t AppDataBuffer[LORAWAN_APP_DATA_BUFFER_MAX_SIZE];

/**
 * @brief User application data structure
 */
static LmHandlerAppData_t AppData = { 0, 0, AppDataBuffer };

/**
 * @brief Specifies the state of the application LED
 */
static uint8_t AppLedStateOn = RESET;
/**
 * Temp buffer to store a FLASH page in RAM when partial replacement is needed
 */
static uint8_t FLASH_RAM_buffer[FLASH_IF_BUFFER_SIZE];
/* USER CODE END PV */

/* Exported functions ---------------------------------------------------------*/
/* USER CODE BEGIN EF */
void cambiaTxPeriodicity(uint32_t periodicity)
{
	OnTxPeriodicityChanged(periodicity);
	//	APP_LOG(TS_OFF, VLEVEL_M, "Tx Time aggiornato: %d\r\n", periodicity);
}

uint32_t leggiTxPeriodicity()
{
	return TxPeriodicity;
}
/* USER CODE END EF */

void LoRaWAN_Init(void)
{
	/* USER CODE BEGIN LoRaWAN_Init_LV */

	uint32_t feature_version = 0UL;
	/* USER CODE END LoRaWAN_Init_LV */

	/* USER CODE BEGIN LoRaWAN_Init_1 */
	/* Get LoRaWAN APP version*/
	APP_LOG(TS_OFF, VLEVEL_M, "APPLICATION_VERSION: V%X.%X.%X\r\n",
			(uint8_t)(APP_VERSION_MAIN),
			(uint8_t)(APP_VERSION_SUB1),
			(uint8_t)(APP_VERSION_SUB2));

	/* Get MW LoRaWAN info */
	APP_LOG(TS_OFF, VLEVEL_M, "MW_LORAWAN_VERSION:  V%X.%X.%X\r\n",
			(uint8_t)(LORAWAN_VERSION_MAIN),
			(uint8_t)(LORAWAN_VERSION_SUB1),
			(uint8_t)(LORAWAN_VERSION_SUB2));

	/* Get MW SubGhz_Phy info */
	APP_LOG(TS_OFF, VLEVEL_M, "MW_RADIO_VERSION:    V%X.%X.%X\r\n",
			(uint8_t)(SUBGHZ_PHY_VERSION_MAIN),
			(uint8_t)(SUBGHZ_PHY_VERSION_SUB1),
			(uint8_t)(SUBGHZ_PHY_VERSION_SUB2));

	/* Get LoRaWAN Link Layer info */
	LmHandlerGetVersion(LORAMAC_HANDLER_L2_VERSION, &feature_version);
	APP_LOG(TS_OFF, VLEVEL_M, "L2_SPEC_VERSION:     V%X.%X.%X\r\n",
			(uint8_t)(feature_version >> 24),
			(uint8_t)(feature_version >> 16),
			(uint8_t)(feature_version >> 8));

	/* Get LoRaWAN Regional Parameters info */
	LmHandlerGetVersion(LORAMAC_HANDLER_REGION_VERSION, &feature_version);
	APP_LOG(TS_OFF, VLEVEL_M, "RP_SPEC_VERSION:     V%X-%X.%X.%X\r\n",
			(uint8_t)(feature_version >> 24),
			(uint8_t)(feature_version >> 16),
			(uint8_t)(feature_version >> 8),
			(uint8_t)(feature_version));



	if (FLASH_IF_Init(FLASH_RAM_buffer) != FLASH_IF_OK)
	{
		Error_Handler();  // XXX: improve this
	}

	/* USER CODE END LoRaWAN_Init_1 */

	UTIL_TIMER_Create(&StopJoinTimer, JOIN_TIME, UTIL_TIMER_ONESHOT, OnStopJoinTimerEvent, NULL);

	UTIL_SEQ_RegTask((1 << CFG_SEQ_Task_LmHandlerProcess), UTIL_SEQ_RFU, LmHandlerProcess);

	UTIL_SEQ_RegTask((1 << CFG_SEQ_Task_LoRaSendOnTxTimerOrButtonEvent), UTIL_SEQ_RFU, SendTxData);
	UTIL_SEQ_RegTask((1 << CFG_SEQ_Task_LoRaStoreContextEvent), UTIL_SEQ_RFU, StoreContext);
	UTIL_SEQ_RegTask((1 << CFG_SEQ_Task_LoRaStopJoinEvent), UTIL_SEQ_RFU, StopJoin);

	/* Init Info table used by LmHandler*/
	LoraInfo_Init();

	/* Init the Lora Stack*/
	LmHandlerInit(&LmHandlerCallbacks, APP_VERSION);

	LmHandlerConfigure(&LmHandlerParams);

	/* USER CODE BEGIN LoRaWAN_Init_2 */
	/* USER CODE END LoRaWAN_Init_2 */

	LmHandlerJoin(ActivationType, ForceRejoin);

	if (EventType == TX_ON_TIMER)
	{
		/* send every time timer elapses */
		UTIL_TIMER_Create(&TxTimer, TxPeriodicity, UTIL_TIMER_ONESHOT, OnTxTimerEvent, NULL);
		UTIL_TIMER_Start(&TxTimer);
	}
	else
	{
		/* USER CODE BEGIN LoRaWAN_Init_3 */

		/* USER CODE END LoRaWAN_Init_3 */
	}

	/* USER CODE BEGIN LoRaWAN_Init_Last */

	/* USER CODE END LoRaWAN_Init_Last */
}

/* USER CODE BEGIN PB_Callbacks */

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	switch (GPIO_Pin)
	{

	case RTSn_Pin:
		// buffer di scrittura: aspettiamo che si svuoti
		HAL_Delay(50);
		GPIO_PinState pin = GPIO_PIN_RESET;
		// leggo se si è alzato o abbasstao il pin
		pin = HAL_GPIO_ReadPin(RTSn_GPIO_Port, RTSn_Pin);
		if (pin == GPIO_PIN_SET)
		{
			// se is è alzato entriamo nella configurazione del nodo sensore, quindi fermando le letture
			if (LORAMAC_HANDLER_SUCCESS != LoRaSTOP())
				return;
			APP_LOG(TS_OFF, VLEVEL_M, "Stack LoRa interrotto correttamente\r\n");
			statoNodo = configurazione;
			UTIL_ADV_TRACE_StartRxProcess(CallbackSeriale);
			APP_LOG(TS_OFF, VLEVEL_M, "Callback da seriale per comandi da interfaccia: inizializzata\r\n");
			/* Disable Stop Mode */
			UTIL_LPM_SetStopMode((1 << CFG_LPM_APPLI_Id), UTIL_LPM_DISABLE);
			/* ACCENDO LED */
			accendiLed();
		}
		else
		{
			HAL_UART_AbortReceive_IT(&hlpuart1);
			LoRaSTART();
			statoNodo = normal;
			/* Disable Stop Mode */
			UTIL_LPM_SetStopMode((1 << CFG_LPM_APPLI_Id), UTIL_LPM_ENABLE);
			spegniLed();
		}
		break;
	}
}

/* USER CODE END PB_Callbacks */

/* Private functions ---------------------------------------------------------*/
/* USER CODE BEGIN PrFD */

/* USER CODE END PrFD */

static void OnRxData(LmHandlerAppData_t *appData, LmHandlerRxParams_t *params)
{
	/* USER CODE BEGIN OnRxData_1 */
	uint8_t RxPort = 0;

	if (params != NULL)
	{


		if (params->IsMcpsIndication)
		{
			if (appData != NULL)
			{
				RxPort = appData->Port;
				if (appData->Buffer != NULL)
				{
					switch (appData->Port)
					{
					case LORAWAN_SWITCH_CLASS_PORT:
						/*this port switches the class*/
						if (appData->BufferSize == 1)
						{
							switch (appData->Buffer[0])
							{
							case 0:
							{
								LmHandlerRequestClass(CLASS_A);
								break;
							}
							case 1:
							{
								LmHandlerRequestClass(CLASS_B);
								break;
							}
							case 2:
							{
								LmHandlerRequestClass(CLASS_C);
								break;
							}
							default:
								break;
							}
						}
						break;
					case LORAWAN_USER_APP_PORT:
						if (appData->BufferSize == 1)
						{
							AppLedStateOn = appData->Buffer[0] & 0x01;
							if (AppLedStateOn == RESET)
							{
								APP_LOG(TS_OFF, VLEVEL_H, "LED OFF\r\n");

							}
							else
							{
								APP_LOG(TS_OFF, VLEVEL_H, "LED ON\r\n");

							}
						}
						break;

					default:

						break;
					}
				}
			}
		}
		if (params->RxSlot < RX_SLOT_NONE)
		{
			APP_LOG(TS_OFF, VLEVEL_H, "###### D/L FRAME:%04d | PORT:%d | DR:%d | SLOT:%s | RSSI:%d | SNR:%d\r\n",
					params->DownlinkCounter, RxPort, params->Datarate, slotStrings[params->RxSlot],
					params->Rssi, params->Snr);
		}
	}
	/* USER CODE END OnRxData_1 */
}

static void SendTxData(void)
{
	/* USER CODE BEGIN SendTxData_1 */
	LmHandlerErrorStatus_t status = LORAMAC_HANDLER_ERROR;
	//	uint8_t batteryLevel = GetBatteryLevel();
	//	sensor_t sensor_data;
	UTIL_TIMER_Time_t nextTxIn = 0;
	uint16_t battVoltage = 0;
	uint16_t internalBattery = 0;
	UTIL_TIMER_Time_t TxPeriodicityModified = TxPeriodicity;

	if (LmHandlerIsBusy() == false)
	{
		uint32_t i = 0;

		//		EnvSensors_Read(&sensor_data);

		//		APP_LOG(TS_ON, VLEVEL_M, "VDDA: %d\r\n", batteryLevel);
		//		APP_LOG(TS_ON, VLEVEL_M, "temp: %d\r\n", (int16_t)(sensor_data.temperature));

		AppData.Port = LORAWAN_USER_APP_PORT;


		// leggo la tensione di batteria

		leggiBatterie(&battVoltage, &internalBattery, false);

		// se sono una certa soglia non effettuo le letture
		if (battVoltage < SOGLIA_BATTERIA_TX)
		{
			APP_LOG( TS_OFF, VLEVEL_M, "\n\r\n\r-----------letture sospese per bassa tensione di batteria----------\n\r");
		}
		else
		{
			APP_LOG( TS_OFF, VLEVEL_M, "\n\r\n\r-----------LETTURADATI DA SENSORI----------\n\r");
			uint16_t VAdc[ANALOG_INPUT], Vref[ANALOG_INPUT];
			float media[MAX_NUM_PINZE], DEVstd[MAX_NUM_PINZE], temperatura[MAX_NUM_PINZE], diameter[MAX_NUM_PINZE];
			tutteLetture(media, DEVstd, VAdc, Vref, temperatura, diameter);
			LowPower();
			PrintADCVoltages(VAdc, Vref);
			PrintPinzaStatistics(media, DEVstd, temperatura, diameter, MAX_NUM_PINZE);

			// organizzo i dati da inviare
			for (uint8_t j = 0; j<MAX_NUM_PINZE; j++)
			{
				AppendFloatToBuffer100(media[j], &i, AppData.Buffer);
			}
			for (uint8_t j = 0; j<ANALOG_INPUT; j++)
			{
				AppendiUint16ToBuffer10(VAdc[j], &i, AppData.Buffer);
			}
			AppendiUint16ToBuffer10(battVoltage, &i, AppData.Buffer);


			/*
			 * QUI CAMBIAMO, SE NECESSARIO, L'INTERVALLO DI TX
			 * RIFERIMENTI a TENSIONE OPEN DELLE BATTERIE LI-ION VS STATO DI CARICA
			 * https://www.sciencedirect.com/science/article/pii/S037877531401026X
			 * https://www.sciencedirect.com/science/article/pii/S0378775308017965
			 * Se siamo sotto il 50% di carica (tensione di batteria < 3.85V) aumentiamo il duty cycle delle letture in funzione della tensione di batteria
			 * proviamo una interpolazione lineare
			 */
			TxPeriodicityModified = interpolate_sampling_time(battVoltage, TxPeriodicity);
			APP_LOG(TS_ON, VLEVEL_L, "VBatt : ~%d\r\n", battVoltage);
//			APP_LOG(TS_ON, VLEVEL_L, "TxPeriodicityModified : ~%d (s)\r\n", (TxPeriodicityModified / 1000));

			if (TxPeriodicityModified != TxPeriodicity)
			{
				APP_LOG(TS_ON, VLEVEL_L, "Periodo modifcato, prossimo Tx in  : ~%d (s)\r\n", (TxPeriodicityModified / 1000));
			}


			AppData.BufferSize = i;
			HAL_Delay(20);

			status = LmHandlerSend(&AppData, LmHandlerParams.IsTxConfirmed, false);
			if (LORAMAC_HANDLER_SUCCESS == status)
			{
				APP_LOG(TS_ON, VLEVEL_L, "SEND REQUEST\r\n");
			}
			else if (LORAMAC_HANDLER_DUTYCYCLE_RESTRICTED == status)
			{
				nextTxIn = LmHandlerGetDutyCycleWaitTime();
				if (nextTxIn > 0)
				{
					APP_LOG(TS_ON, VLEVEL_L, "Next Tx in  : ~%d second(s)\r\n", (nextTxIn / 1000));
				}
			}
		}
	}

	if (EventType == TX_ON_TIMER)
	{
		UTIL_TIMER_Stop(&TxTimer);
		UTIL_TIMER_SetPeriod(&TxTimer, MAX(nextTxIn, TxPeriodicityModified));
		UTIL_TIMER_Start(&TxTimer);
	}

	/* USER CODE END SendTxData_1 */
}

static void OnTxTimerEvent(void *context)
{
	/* USER CODE BEGIN OnTxTimerEvent_1 */

	/* USER CODE END OnTxTimerEvent_1 */
	UTIL_SEQ_SetTask((1 << CFG_SEQ_Task_LoRaSendOnTxTimerOrButtonEvent), CFG_SEQ_Prio_0);

	/*Wait for next tx slot*/
	UTIL_TIMER_Start(&TxTimer);
	/* USER CODE BEGIN OnTxTimerEvent_2 */

	/* USER CODE END OnTxTimerEvent_2 */
}

/* USER CODE BEGIN PrFD_LedEvents */

/* USER CODE END PrFD_LedEvents */

static void OnTxData(LmHandlerTxParams_t *params)
{
	/* USER CODE BEGIN OnTxData_1 */
	if ((params != NULL))
	{
		/* Process Tx event only if its a mcps response to prevent some internal events (mlme) */
		if (params->IsMcpsConfirm != 0)
		{


			APP_LOG(TS_OFF, VLEVEL_M, "\r\n###### ========== MCPS-Confirm =============\r\n");
			APP_LOG(TS_OFF, VLEVEL_H, "###### U/L FRAME:%04d | PORT:%d | DR:%d | PWR:%d", params->UplinkCounter,
					params->AppData.Port, params->Datarate, params->TxPower);

			APP_LOG(TS_OFF, VLEVEL_H, " | MSG TYPE:");
			if (params->MsgType == LORAMAC_HANDLER_CONFIRMED_MSG)
			{
				APP_LOG(TS_OFF, VLEVEL_H, "CONFIRMED [%s]\r\n", (params->AckReceived != 0) ? "ACK" : "NACK");
			}
			else
			{
				APP_LOG(TS_OFF, VLEVEL_H, "UNCONFIRMED\r\n");
			}
		}
	}
	/* USER CODE END OnTxData_1 */
}

static void OnJoinRequest(LmHandlerJoinParams_t *joinParams)
{
	/* USER CODE BEGIN OnJoinRequest_1 */
	if (joinParams != NULL)
	{
		if (joinParams->Status == LORAMAC_HANDLER_SUCCESS)
		{
			UTIL_SEQ_SetTask((1 << CFG_SEQ_Task_LoRaStoreContextEvent), CFG_SEQ_Prio_0);

			APP_LOG(TS_OFF, VLEVEL_M, "\r\n###### = JOINED = ");
			if (joinParams->Mode == ACTIVATION_TYPE_ABP)
			{
				APP_LOG(TS_OFF, VLEVEL_M, "ABP ======================\r\n");
			}
			else
			{
				APP_LOG(TS_OFF, VLEVEL_M, "OTAA =====================\r\n");
			}
		}
		else
		{
			APP_LOG(TS_OFF, VLEVEL_M, "\r\n###### = JOIN FAILED\r\n");

			if (joinParams->Mode == ACTIVATION_TYPE_OTAA) {
				APP_LOG(TS_OFF, VLEVEL_M, "\r\n###### = RE-TRYING OTAA JOIN\r\n");
				/* re-try the OTAA join */
				LmHandlerJoin(ActivationType, LORAWAN_FORCE_REJOIN_AT_BOOT);
			}
		}
	}
	/* USER CODE END OnJoinRequest_1 */
}

static void OnBeaconStatusChange(LmHandlerBeaconParams_t *params)
{
	/* USER CODE BEGIN OnBeaconStatusChange_1 */
	if (params != NULL)
	{
		switch (params->State)
		{
		default:
		case LORAMAC_HANDLER_BEACON_LOST:
		{
			APP_LOG(TS_OFF, VLEVEL_M, "\r\n###### BEACON LOST\r\n");
			break;
		}
		case LORAMAC_HANDLER_BEACON_RX:
		{
			APP_LOG(TS_OFF, VLEVEL_M,
					"\r\n###### BEACON RECEIVED | DR:%d | RSSI:%d | SNR:%d | FQ:%d | TIME:%d | DESC:%d | "
					"INFO:02X%02X%02X %02X%02X%02X\r\n",
					params->Info.Datarate, params->Info.Rssi, params->Info.Snr, params->Info.Frequency,
					params->Info.Time.Seconds, params->Info.GwSpecific.InfoDesc,
					params->Info.GwSpecific.Info[0], params->Info.GwSpecific.Info[1],
					params->Info.GwSpecific.Info[2], params->Info.GwSpecific.Info[3],
					params->Info.GwSpecific.Info[4], params->Info.GwSpecific.Info[5]);
			break;
		}
		case LORAMAC_HANDLER_BEACON_NRX:
		{
			APP_LOG(TS_OFF, VLEVEL_M, "\r\n###### BEACON NOT RECEIVED\r\n");
			break;
		}
		}
	}
	/* USER CODE END OnBeaconStatusChange_1 */
}

static void OnSysTimeUpdate(void)
{
	/* USER CODE BEGIN OnSysTimeUpdate_1 */

	/* USER CODE END OnSysTimeUpdate_1 */
}

static void OnClassChange(DeviceClass_t deviceClass)
{
	/* USER CODE BEGIN OnClassChange_1 */
	APP_LOG(TS_OFF, VLEVEL_M, "Switch to Class %c done\r\n", "ABC"[deviceClass]);
	/* USER CODE END OnClassChange_1 */
}

static void OnMacProcessNotify(void)
{
	/* USER CODE BEGIN OnMacProcessNotify_1 */

	/* USER CODE END OnMacProcessNotify_1 */
	UTIL_SEQ_SetTask((1 << CFG_SEQ_Task_LmHandlerProcess), CFG_SEQ_Prio_0);

	/* USER CODE BEGIN OnMacProcessNotify_2 */

	/* USER CODE END OnMacProcessNotify_2 */
}

static void OnTxPeriodicityChanged(uint32_t periodicity)
{
	/* USER CODE BEGIN OnTxPeriodicityChanged_1 */

	/* USER CODE END OnTxPeriodicityChanged_1 */
	TxPeriodicity = periodicity;

	if (TxPeriodicity == 0)
	{
		/* Revert to application default periodicity */
		TxPeriodicity = APP_TX_DUTYCYCLE;
	}

	/* Update timer periodicity */
	UTIL_TIMER_Stop(&TxTimer);
	UTIL_TIMER_SetPeriod(&TxTimer, TxPeriodicity);
	UTIL_TIMER_Start(&TxTimer);
	/* USER CODE BEGIN OnTxPeriodicityChanged_2 */

	/* USER CODE END OnTxPeriodicityChanged_2 */
}

static void OnTxFrameCtrlChanged(LmHandlerMsgTypes_t isTxConfirmed)
{
	/* USER CODE BEGIN OnTxFrameCtrlChanged_1 */

	/* USER CODE END OnTxFrameCtrlChanged_1 */
	LmHandlerParams.IsTxConfirmed = isTxConfirmed;
	/* USER CODE BEGIN OnTxFrameCtrlChanged_2 */

	/* USER CODE END OnTxFrameCtrlChanged_2 */
}

static void OnPingSlotPeriodicityChanged(uint8_t pingSlotPeriodicity)
{
	/* USER CODE BEGIN OnPingSlotPeriodicityChanged_1 */

	/* USER CODE END OnPingSlotPeriodicityChanged_1 */
	LmHandlerParams.PingSlotPeriodicity = pingSlotPeriodicity;
	/* USER CODE BEGIN OnPingSlotPeriodicityChanged_2 */

	/* USER CODE END OnPingSlotPeriodicityChanged_2 */
}

static void OnSystemReset(void)
{
	/* USER CODE BEGIN OnSystemReset_1 */

	/* USER CODE END OnSystemReset_1 */
	if ((LORAMAC_HANDLER_SUCCESS == LmHandlerHalt()) && (LmHandlerJoinStatus() == LORAMAC_HANDLER_SET))
	{
		NVIC_SystemReset();
	}
	/* USER CODE BEGIN OnSystemReset_Last */

	/* USER CODE END OnSystemReset_Last */
}

static void StopJoin(void)
{
	/* USER CODE BEGIN StopJoin_1 */

	/* USER CODE END StopJoin_1 */

	UTIL_TIMER_Stop(&TxTimer);

	if (LORAMAC_HANDLER_SUCCESS != LmHandlerStop())
	{
		APP_LOG(TS_OFF, VLEVEL_M, "LmHandler Stop on going ...\r\n");
	}
	else
	{
		APP_LOG(TS_OFF, VLEVEL_M, "LmHandler Stopped\r\n");
		if (LORAWAN_DEFAULT_ACTIVATION_TYPE == ACTIVATION_TYPE_ABP)
		{
			ActivationType = ACTIVATION_TYPE_OTAA;
			APP_LOG(TS_OFF, VLEVEL_M, "LmHandler switch to OTAA mode\r\n");
		}
		else
		{
			ActivationType = ACTIVATION_TYPE_ABP;
			APP_LOG(TS_OFF, VLEVEL_M, "LmHandler switch to ABP mode\r\n");
		}
		LmHandlerConfigure(&LmHandlerParams);
		LmHandlerJoin(ActivationType, true);
		UTIL_TIMER_Start(&TxTimer);
	}
	UTIL_TIMER_Start(&StopJoinTimer);
	/* USER CODE BEGIN StopJoin_Last */

	/* USER CODE END StopJoin_Last */
}

static void OnStopJoinTimerEvent(void *context)
{
	/* USER CODE BEGIN OnStopJoinTimerEvent_1 */

	/* USER CODE END OnStopJoinTimerEvent_1 */
	if (ActivationType == LORAWAN_DEFAULT_ACTIVATION_TYPE)
	{
		UTIL_SEQ_SetTask((1 << CFG_SEQ_Task_LoRaStopJoinEvent), CFG_SEQ_Prio_0);
	}
	/* USER CODE BEGIN OnStopJoinTimerEvent_Last */

	/* USER CODE END OnStopJoinTimerEvent_Last */
}

static void StoreContext(void)
{
	LmHandlerErrorStatus_t status = LORAMAC_HANDLER_ERROR;

	/* USER CODE BEGIN StoreContext_1 */

	/* USER CODE END StoreContext_1 */
	status = LmHandlerNvmDataStore();

	if (status == LORAMAC_HANDLER_NVM_DATA_UP_TO_DATE)
	{
		APP_LOG(TS_OFF, VLEVEL_M, "NVM DATA UP TO DATE\r\n");
	}
	else if (status == LORAMAC_HANDLER_ERROR)
	{
		APP_LOG(TS_OFF, VLEVEL_M, "NVM DATA STORE FAILED\r\n");
	}
	/* USER CODE BEGIN StoreContext_Last */

	/* USER CODE END StoreContext_Last */
}

static void OnNvmDataChange(LmHandlerNvmContextStates_t state)
{
	/* USER CODE BEGIN OnNvmDataChange_1 */

	/* USER CODE END OnNvmDataChange_1 */
	if (state == LORAMAC_HANDLER_NVM_STORE)
	{
		APP_LOG(TS_OFF, VLEVEL_M, "NVM DATA STORED\r\n");
	}
	else
	{
		APP_LOG(TS_OFF, VLEVEL_M, "NVM DATA RESTORED\r\n");
	}
	/* USER CODE BEGIN OnNvmDataChange_Last */

	/* USER CODE END OnNvmDataChange_Last */
}

static void OnStoreContextRequest(void *nvm, uint32_t nvm_size)
{
	/* USER CODE BEGIN OnStoreContextRequest_1 */

	/* USER CODE END OnStoreContextRequest_1 */
	FLASH_IF_Write(LORAWAN_NVM_BASE_ADDRESS, (const void *)nvm, nvm_size);

	/* USER CODE BEGIN OnStoreContextRequest_Last */

	/* USER CODE END OnStoreContextRequest_Last */
}

static void OnRestoreContextRequest(void *nvm, uint32_t nvm_size)
{
	/* USER CODE BEGIN OnRestoreContextRequest_1 */

	/* USER CODE END OnRestoreContextRequest_1 */
	FLASH_IF_Read(nvm, LORAWAN_NVM_BASE_ADDRESS, nvm_size);
	/* USER CODE BEGIN OnRestoreContextRequest_Last */

	/* USER CODE END OnRestoreContextRequest_Last */
}

